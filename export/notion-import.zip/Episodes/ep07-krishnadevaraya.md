# Ep 7 — Krishnadevaraya: The Emperor of Vijayanagara

## 1. HOOK (0:00–0:50)
In the early 1520s, a Portuguese horse-trader named Domingo Paes rode into a city in southern India and could hardly believe what he saw. He wrote that it was as large as Rome, and one of the best-provided cities in the world. The streets were crowded, the markets sold diamonds, pearls and silks, and the king's palace was like nothing in Europe.
*Visual: Hampi ruins at sunrise, then a reconstruction of the busy city*
The city was Vijayanagara, and the king who ruled it was Krishnadevaraya. He was a warrior who never lost a major battle, a poet who wrote in Telugu, and a builder who covered the south with temples. In this video, we will follow his short and brilliant reign, and ask what came after.
*Visual: map of Vijayanagara and the Deccan*

## 2. THE EMPIRE BEFORE HIM (0:50–3:30)
The Vijayanagara Empire was founded in 1336 by two brothers, Harihara and Bukka. According to tradition, they had served the Delhi Sultanate and then went back to their Hindu roots, helped by a sage named Vidyaranya. Historians debate the exact details, but the empire arose during a time when the Delhi Sultanate was pushing into the south, and a counter-power was needed.
*Visual: founding of Vijayanagara on the Tungabhadra, Hampi hills*
The capital was built on the south bank of the Tungabhadra river, among huge granite boulders, at a place now called Hampi. For the next two centuries it grew into a rich state which controlled most of south India.
Its main rivals were the Bahmani Sultanate, which ruled the northern Deccan from Gulbarga and Bidar, and which broke up around 1500 into five smaller sultanates: Bijapur, Golconda, Ahmednagar, Berar and Bidar. In the east, the Gajapati kings of Odisha pushed down the coast.
*Visual: Bahmani breakup into five sultanates, Gajapati kingdom*
By the end of the fifteenth century, Vijayanagara had a weak and divided leadership. The first dynasty, the Sangamas, gave way to the Saluvas in the 1480s. Then a general named Narasa Nayaka became the real power behind the throne, and in 1505 his son Vira Narasimha took the crown, founding the Tuluva dynasty. Vira Narasimha ruled until 1509.
In 1509, Viranarasimha died. His half-brother took the throne. He was Krishnadevaraya.

## 3. THE YOUNG KING (3:30–5:10)
Krishnadevaraya took the throne in July 1509, and was formally crowned in January 1510. He was born in 1471, according to the most common dating, which means he was in his late thirties, not a teenager. He was the son of Narasa Nayaka and Nagaladevi.
*Visual: coronation scene, young king*
His minister Timmarusu, a respected statesman, guided him in his early years. Later tradition says Timmarusu helped him come to the throne. Krishnadevaraya's court histories always praise the minister as the real wise man behind the throne.
The early years were not easy. Vijayanagara faced the sultanates in the north and the Gajapatis in the east, while some of its own chiefs, the nayakas, were looking to break away. Krishnadevaraya had to act decisively. He reorganised the army, with infantry, cavalry and war elephants, and made a smart move: he sought Portuguese guns and Arabian horses, which came through the new Portuguese port of Goa, taken by Albuquerque in 1510. Sources show him negotiating with the Portuguese about the horse trade, though not a formal treaty.
*Visual: Goa port, horses unloaded from ships, Portuguese gunners*

## 4. WAR WITH THE SULTANS AND THE GAJAPATIS (5:10–9:00)
His first big victories came against the sultanates. In the early years, he marched north and defeated Bijapur and its allies. He pushed into the Raichur Doab, the rich land between the Krishna and Tungabhadra rivers, which was the great prize that Vijayanagara and the Bahmani kings had fought over for 150 years.
*Visual: map of the Raichur Doab between two rivers*
Then came the east. Between 1513 and 1518, Krishnadevaraya fought the Gajapati king Prataparudra in a series of campaigns. In 1514 he took the fort of Udayagiri, and the next year he took Kondavidu, a key fortress on the Krishna river. In the end he reached the Odisha border, and then made peace. He married Prataparudra's daughter, or according to some accounts, a princess of the Gajapati family, as part of the settlement.
*Visual: Udayagiri hill fort, siege, then a wedding*
He did not push into Odisha itself. Historians think he saw the Odisha lands as hard to hold and costly to rule, and preferred an alliance.
Meanwhile he dealt with internal rebels. He crushed chiefs in Ummattur and elsewhere who had defied the crown.
*Visual: rebel forts, nayaka chiefs*
His greatest battle was the one at Raichur in 1520. The Bijapur ruler, Ismail Adil Shah, had retaken the area. Krishnadevaraya raised a huge army, which the Portuguese chronicler Fernão Nuniz says included about 703,000 infantry, 32,600 cavalry and 551 elephants, an obvious exaggeration. Domingo Paes, who was probably present, left a vivid account.
*Visual: Raichur fort, huge army marching*
On 19 May 1520, the two sides met. At first the Vijayanagara army suffered a setback. Then the king himself led a charge, rallied his men and routed the Bijapur forces. Raichur fell. In its aftermath, Krishnadevaraya reportedly refused the Sultan's pleas for peace and even marched towards Bijapur, though most scholars see his victory as a matter of pride rather than conquest.
*Visual: king leading a charge, banners*

## 5. THE CITY AND THE ECONOMY (9:00–12:00)
Now let us look at Vijayanagara in its peak, through the eyes of foreign visitors.
*Visual: reconstruction of the royal centre, Hampi*
Domingo Paes visited around 1520, and Fernão Nunes around 1535. Their accounts survive. Paes describes a great city encircled by seven lines of walls. The royal palace was grand, with carved pillars and ivory. The Mahanavami festival, held every autumn, was a spectacle of parades, dances, wrestling, and animal sacrifices.
Paes says there were bazaars where you could buy rubies, diamonds, pearls, cloth, spices, and fruit. He says the city was well supplied with water from tanks and canals, and that the king himself loved gardens.
*Visual: bazaar, lotus mahal, stepped tank*
The economy rested on agriculture, helped by irrigation. Krishnadevaraya built great tanks and canals fed by the Tungabhadra. A famous inscription describes the building of the Basavanna canal. He also founded a new suburb, Nagalapura, named after his mother, with a big tank.
Trade grew. Ships from Goa and Malabar carried pepper, cotton cloth, and horses. The Portuguese made a treaty to supply him with horses, and kept their rivals out.
*Visual: trade routes, pepper, textiles*
The Vijayanagara army was a major employer. The nayaka system gave military leaders land in return for providing soldiers. It worked well when the king was strong, and became a problem when he was weak.

## 6. TEMPLES, POETRY, AND THE COURT (12:00–15:00)
Krishnadevaraya was a great patron of religion and the arts. He was a devout Vaishnava, a devotee of Vishnu, but he gave gifts to Shiva temples and Jain temples as well. His inscriptions record his gifts to Tirupati, which he visited several times, and to Srirangam, Chidambaram and Kanchipuram.
*Visual: Tirumala temple, gopuram, Srirangam*
In Hampi, he is credited with the Hazara Rama temple, whose walls carry carvings of scenes from the Ramayana, and with work on the huge Vittala temple, with its famous stone chariot. Scholars are not certain which parts date from his reign. The gateways, called gopurams, which tower over many south Indian temples, grew taller under his rule.
*Visual: Hazara Rama temple carvings, Vittala stone chariot*
He was also a poet. He wrote a Telugu epic called Amuktamalyada, about the Tamil poet-saint Andal. In it, he included a section on how to rule, which says a king should make his subjects prosper and should look after merchants, farmers and brahmins alike.
His court had eight famous Telugu poets, known as the Ashtadiggajas, the eight elephants who held up the world. They included Allasani Peddana, whose book Manucharitramu is a classic. The folk tales of the court jester Tenali Rama, who is credited with clever answers to difficult problems, are loved to this day. Historians cannot confirm many of the stories. But they show how deeply the king remains in popular memory.
*Visual: eight poets in a hall, Tenali Rama folk tale*
He is called Andhra Bhoja, the Bhoja of the Telugus, and Kannada Rajya Rama Ramana, because he supported Kannada, Telugu, Tamil and Sanskrit alike.

## 7. THE END OF HIS REIGN (15:00–16:30)
His last years were sad. He made his young son Tirumala Raya heir, and then the boy died, in 1524, perhaps by poison. The king, grieved, was said to have lost his spirit. Rumour blamed the minister Timmarusu, and some accounts say the king had him and his son blinded. The facts remain uncertain.
*Visual: heir's death, court intrigue silhouettes*
Krishnadevaraya died on 17 October 1529, aged about fifty-eight. His half-brother Achyuta Raya succeeded him. The succession was messy. Soon his nephew Sadasiva Raya was crowned, while power slipped to his son-in-law, Aliya Rama Raya.
*Visual: Achyuta Raya, Sadasiva Raya, Rama Raya*

## 8. LEGACY AND DEBATE (16:30–18:00)
In 1565, the combined armies of the Deccan sultanates defeated Vijayanagara at the battle of Talikota. The city was looted and abandoned. The great capital became the ruins of Hampi we see today.
*Visual: Hampi ruins, the sack*
Krishnadevaraya's reign, 1509 to 1529, is seen as the high point of Vijayanagara. He extended its borders from the Krishna river to the southern tip, built temples, and left a memory of good government.
Historians debate how centralised the empire was, how far the Portuguese influenced its military success, and how to read the foreign chroniclers who both admired and exaggerated.
*Visual: two sources side by side, Paes and Nuniz*
Next, we visit Rajasthan, and the defiant Maharana Pratap of Mewar. Subscribe, and tell me in the comments which king you want after that.
*Visual: end screen*

## Fact-check flags
- [ ] Accession July 1509, coronation Jan 1510; b. 1471 (Wikipedia).
- [ ] Narasa Nayaka 1505; Viranarasimha died 1509; Timmarusu's role.
- [ ] Udayagiri 1514, Kondavidu 1515; marriage with a Gajapati princess (Nuniz? Telugu sources).
- [ ] Raichur 19 May 1520 (Paes / Nuniz); army figures from Nuniz are exaggerated.
- [ ] Tirupati: seven visits (inscriptions).
- [ ] Death of the heir 1524; blinding of Timmarusu (Nuniz): disputed.
- [ ] Death 1529; Talikota 1565.
- [ ] Ashtadiggajas list: tradition.
- [ ] Albuquerque took Goa 1510.

## Metadata
Title: Krishnadevaraya: The Greatest Emperor of Vijayanagara
Hook: A warrior who never lost a major battle, a poet, and the ruler of a city as big as Rome. The reign of Krishnadevaraya and the empire at Hampi.
Tags: Krishnadevaraya, Vijayanagara Empire, Hampi, Tenali Rama, Raichur, Domingo Paes, South Indian history, history of kings
Hashtags: #Krishnadevaraya #Vijayanagara #Hampi #HistoryOfKings
Sources:
- Robert Sewell, A Forgotten Empire: Vijayanagar (Paes and Nuniz chronicles)
- K.A. Nilakanta Sastri and N. Venkataramanayya, Further Sources of Vijayanagara History
- Burton Stein, Vijayanagara (New Cambridge History of India)
- Vasundhara Filliozat, Vijayanagar
- Phillip Wagoner, Tidings of the King

## Fact-check log
| Claim | Verdict | Notes |
|---|---|---|
| Crowned 8 Aug 1509 aged ~19 | WRONG — FIXED | Reign from 26 July 1509; coronation 23/24 Jan 1510; born 17 Jan (or 16 Feb) 1471, so late thirties |
| Died 1529 aged ~39 | WRONG — FIXED | Died 17 Oct 1529 aged 58 (inscription) |
| Narasa Nayaka founded Tuluva dynasty in 1505 | WRONG — FIXED | Vira Narasimha (his son) took the throne in 1505; Narasa was the general/regent |
| Raichur 19 May 1520, Ismail Adil Shah | Verified | Ismail retook Raichur while Krishnadevaraya was in Odisha |
| Army at Raichur (Nuniz: 703,000 foot, 32,600 horse, 551 elephants) | Verified as Nuniz's figure; exaggerated | Name is Nuniz — script FIXED |
| Udayagiri 1514, Kondavidu 1515; Prataparudra gave daughter | Verified | |
| Paes: "as large as Rome" | Verified | |
| Goa captured 1510 | Verified | "Treaty" for horses NOT verified (only 1514 proposals) — FIXED |
| Seven visits to Tirupati | Not verified — FIXED to "several" | |
| Hazara Rama, Vittala built by him | Partly (attribution speculative) — FIXED | |
| Heir poisoned 1524; Timmarusu blinded | Reported, uncertain | Script hedged |
| Amuktamalyada; Ashtadiggajas incl. Allasani Peddana | Verified | List of eight varies |
| Vijayanagara founded 1336 (Harihara, Bukka, Vidyaranya) | Verified | |
| Talikota 1565 | Verified | |
