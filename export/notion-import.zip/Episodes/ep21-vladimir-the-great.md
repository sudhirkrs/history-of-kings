# Ep 21 — Vladimir the Great: The Prince Who Chose a Faith for Russia

## 1. HOOK (0:00–0:50)
A thousand years ago, the ruler of Kiev sent envoys across the known world to look at religions. They visited Muslim Bulgars, German Christians, and finally Constantinople. In the great church of Hagia Sophia, according to the Russian Primary Chronicle, they said: we did not know whether we were in heaven or on earth. For on earth there is no such splendour or beauty.
*Visual: Hagia Sophia interior, envoys looking up*
That ruler was Vladimir, later called the Great and the Saint. He began as a pagan warlord with hundreds of wives, according to the chronicle. He ended as the man who brought Christianity to the East Slavs, in a decision that shaped the history of Russia, Ukraine and Belarus. This is his story, and the question of how much of it is history, and how much a legend.
*Visual: Vladimir statue in Kyiv, map of Kievan Rus'*

## 2. THE LAND OF RUS' (0:50–3:00)
In the ninth century, Scandinavian traders and warriors, known in the east as Rus' or Varangians, moved along the rivers of eastern Europe. They mixed with the Slavs and Finns who lived there. According to the Primary Chronicle, the people of Novgorod invited a prince named Rurik to rule them around 862. His successor Oleg moved south and took Kiev around 882.
*Visual: Viking boats on rivers, Rurik, Oleg taking Kiev*
The Rus' state grew rich by trade. Furs, honey, wax and slaves were taken down the Dnieper to Constantinople, the greatest city in Christendom. Sometimes they traded; sometimes they raided. In 941 and 944 the Rus' prince Igor attacked Constantinople, and was bought off by treaties.
Igor's widow Olga ruled as regent and visited Constantinople in the 950s, and was baptised. She is the first Rus' ruler to become a Christian. But her son Sviatoslav refused. He was a warrior who destroyed the Khazar kingdom in the 960s and invaded Bulgaria. In 972, on his way home, he was killed by the Pechenegs, steppe nomads, who made a drinking cup from his skull, according to the chronicle.
*Visual: Olga's baptism, Sviatoslav and the Khazars, the Pecheneg ambush*

## 3. THE SON OF A SLAVE-GIRL (3:00–5:30)
Vladimir was born around 958, the youngest son of Sviatoslav. His mother, Malusha, was a housekeeper in Olga's household. In the eyes of the nobles, he was a son of a slave, not a prince of full rank.
*Visual: young Vladimir, Malusha*
When Sviatoslav died, his three sons fought for power. Yaropolk got Kiev. Oleg got the land of the Drevlyans. Vladimir was sent to Novgorod. In 977, Yaropolk's men killed Oleg. Vladimir fled to Scandinavia, to his relatives, and raised an army of Varangians.
In 978, he came back and attacked. On the way he took the city of Polotsk, whose prince Rogvolod refused to give his daughter Rogneda in marriage to the son of a slave. Vladimir killed Rogvolod and his sons and took Rogneda by force. Then he marched on Kiev, besieged Yaropolk, tricked him into negotiating, and had him murdered. He became the ruler of all the Rus' lands.
*Visual: Vladimir's return, Polotsk, siege of Kiev*
This is the young Vladimir of the chronicles: brutal, ambitious and lustful. The Primary Chronicle says he had several wives and some 800 concubines. The numbers are probably an exaggeration, a way for the writer to show the contrast with Christian Vladimir. Other sources count about seven wives.

## 4. THE PAGAN PRINCE (5:30–7:30)
In his first years, Vladimir ruled as a pagan. In Kiev, he set up a row of wooden idols on a hill near his palace. The chief was Perun, the god of thunder, with a silver head and a golden moustache. Others were Khors, Dazhbog, Stribog, Simargl and Mokosh. According to the chronicle, humans were sacrificed. Historians debate how reliable this is.
*Visual: idols on a hill in Kiev*
He also fought. He conquered the Polish Cherven towns, defeated the Yotvingians, and the Volga Bulgars, and strengthened his borders. In 983, as the story goes, a Christian Varangian and his son were chosen by lot for sacrifice. The father refused to hand over his son, saying that these were not gods but wood. The crowd killed both. They are known as the first Christian martyrs in Rus'.
*Visual: sacrifice by lot, the crowd*
Vladimir was building a state. But paganism, with local gods, did not unite a growing territory. Neighbouring monarchs were Christian, Muslim or Jewish. He needed a faith that matched his ambitions.

## 5. THE CHOICE OF FAITH (7:30–10:30)
Now the famous story from the Primary Chronicle, compiled about 1113, a century after the events.
*Visual: chronicle manuscript*
In 986 or 987, according to the chronicle, envoys came to Vladimir from different religions. The Muslim Bulgars of the Volga came first. Vladimir liked the idea of many wives, but he rejected the ban on pork and wine. According to the story, he said: drinking is the joy of the Rus'; we cannot exist without that pleasure.
Next came Jewish Khazars. He asked where their homeland was, and when told that God had scattered them in punishment for their sins, he said: how can you teach others, when you yourselves are cast out?
Then came the Germans, representing Latin Christianity. Vladimir sent them away, saying that his ancestors had not accepted that faith.
Finally, a Greek philosopher explained the Orthodox faith. Vladimir sent ten wise men to see for themselves. Among the Bulgars they saw no joy; among the Germans no beauty. But in Constantinople, they were taken to a service at Hagia Sophia, and returned with the famous words: we did not know whether we were in heaven or on earth.
*Visual: four envoys in a row, Hagia Sophia*
Historians see this as a literary story, not a real record. The chronicle was written by monks and has the standard shape of a conversion tale. The real reason, historians suggest, was political. Vladimir already knew about Byzantium from his grandmother Olga and trade. Becoming Orthodox linked him with the richest and most prestigious state in Europe.

## 6. THE BYZANTINE BARGAIN (10:30–13:30)
The real events were driven by war. In 987, the Byzantine Emperor Basil II faced a massive rebellion by the general Bardas Phokas, who had proclaimed himself emperor. Basil was in danger.
*Visual: Basil II, Bardas Phokas rebellion*
Basil asked Vladimir for military help. Vladimir offered about 6,000 Varangian warriors, on one condition: he would marry the emperor's sister, Anna. This was extraordinary. Byzantine princesses born in the purple were not given to foreign rulers, least of all pagan barbarians. Basil agreed, but only if Vladimir was baptised.
Vladimir accepted. The Varangian troops arrived in Constantinople in 988, and fought Phokas. Phokas died in 989, perhaps of a stroke, and the revolt collapsed. The Varangians stayed on to form the Emperor's famous Varangian Guard.
*Visual: Varangians arriving, the Varangian Guard*
But then Basil delayed sending Anna. Vladimir attacked the Byzantine city of Cherson in Crimea, which fell after a siege. Now Basil had to give in. Anna came, and Vladimir was baptised, either in Cherson or in Kiev or on his estate near it, in 987, 988 or 989, depending on the source. Traditional dating is 988. Some scholars even treat the Cherson story as a legend.
*Visual: siege of Cherson, baptism, Anna arriving*
It was a masterpiece of diplomacy. Vladimir became the brother-in-law of the emperor, and gained a Christian crown, while Byzantium gained an ally, and a vast new Christian land.

## 7. THE BAPTISM OF RUS' (13:30–16:00)
After his baptism, Vladimir set out to Christianise his people. He sent away his wives and concubines. He ordered the idols to be torn down. Perun was dragged behind a horse, beaten with sticks, and thrown into the Dnieper river.
*Visual: toppling of Perun*
The people of Kiev were then ordered to go to the river to be baptised. The chronicle says all came, and priests read prayers from the banks, while people stood in the water. Not all accepted willingly, and in some regions, such as Novgorod, there was resistance. A pagan uprising there in 991 or 992 was put down. Historians say the Christianisation of the countryside took generations.
*Visual: mass baptism in the Dnieper*
Vladimir built the Church of the Tithes in Kiev, finished around 996, and devoted a tenth of his income to it. The church had clergy from Byzantium and Bulgaria. Old Church Slavonic, the Bulgarian language of the Cyrillic Bible, became the language of worship. This was important. Unlike in Western Europe, where Latin dominated, the Rus' had scripture in a language people could understand.
*Visual: Church of the Tithes, Cyrillic manuscript*
He also minted coins with his image and a trident, the symbol of his dynasty, which is today the national emblem of Ukraine. He built forts along the southern border against the Pechenegs, and settled people there.

## 8. THE LAST YEARS (16:00–17:30)
Vladimir governed through his sons, placing them in major cities. Yaroslav in Novgorod, Boris in Rostov, Gleb in Murom, Sviatopolk in Turov. In his last years, there was a tension. Yaroslav of Novgorod refused to pay tribute, and Vladimir was preparing war against his own son when he died, on 15 July 1015, at Berestovo, near Kiev.
*Visual: sons in cities, Vladimir's death*
A terrible struggle followed. Sviatopolk, who is said to have been the son of Yaropolk's widow, seized Kiev and killed his half-brothers Boris and Gleb. They became the first Russian saints, honoured for accepting death without fighting. Yaroslav defeated Sviatopolk at Lyubech in 1016 and in a final battle in 1019, and went on to rule Kiev as Yaroslav the Wise.
*Visual: Boris and Gleb icon, Yaroslav's victory*

## 9. LEGACY AND DEBATE (17:30–19:00)
Vladimir was made a saint in the Orthodox Church. Today, statues of him stand in Kyiv and in Moscow. He is claimed by Ukraine, Russia and Belarus as a founder of their statehood and Christian heritage.
*Visual: two statues of Vladimir, Kyiv and Moscow*
This makes history hard. In the 988 state, Kiev was the capital, and the Rus' lands were a federation of cities. The modern nations did not exist. Historians say that it is anachronistic to call him Russian or Ukrainian. He was a prince of Rus', and the heritage is shared, which is why it is contested.
Historians also debate the date of the baptism, the sources of the chronicles, how widespread paganism was, and how strong his rule was outside Kiev.
*Visual: question cards*
Next, we go to the German princess who became a Russian empress and seized the throne: Catherine the Great. Subscribe, and tell me which king you want after that.
*Visual: end screen*

## Fact-check flags
- [ ] Vladimir b. ~958; Malusha; Oleg's death 977; return 978; Rogneda; Yaropolk's murder.
- [ ] 983 martyrdom of Theodore and John (Primary Chronicle).
- [ ] Choice of faith 986: literary; delegation; "heaven or earth" quote.
- [ ] Basil II / Bardas Phokas 987–989; 6,000 Varangians; Anna; Cherson; date of baptism 987/988/989.
- [ ] Church of the Tithes (989–996); coinage; trident.
- [ ] Death 15 July 1015; Boris and Gleb; Yaroslav 1019.
- [ ] Rurik 862 / Oleg 882 chronology (Primary Chronicle).
- [ ] Sviatoslav's skull-cup story.

## Metadata
Title: Vladimir the Great: How One Prince Chose a Faith for Russia
Hook: From pagan warlord to saint: the baptism of Rus' in 988, the Byzantine bargain behind it and the legends the chroniclers added.
Tags: Vladimir the Great, Kievan Rus, Kyiv, Orthodox Christianity, Byzantine Empire, Basil II, Russian history, Ukrainian history, history of kings
Hashtags: #VladimirTheGreat #KievanRus #HistoryOfKings
Sources:
- The Russian Primary Chronicle, trans. Cross and Sherbowitz-Wetzor
- Simon Franklin and Jonathan Shepard, The Emergence of Rus 750-1200
- Serhii Plokhy, The Origins of the Slavic Nations
- Janet Martin, Medieval Russia 980-1584
- Dimitri Obolensky, The Byzantine Commonwealth

## Fact-check log
| Claim | Verdict | Notes |
|---|---|---|
| Born c. 956–958; mother Malusha (identity disputed); died 15 July 1015 at Berestovo | Verified | |
| Yaropolk war 977–78; Rogneda/Polotsk | Verified (Britannica says "about seven wives") | 800 concubines is Primary Chronicle's claim — FIXED to attribute |
| Perun idol in Kiev | Not verified in search | From the Primary Chronicle |
| Choice of faith (986/987), "heaven or earth" | Verified as LITERARY/legendary | Scholars range from accepting to rejecting; script already says so |
| Basil II asked for help vs Bardas Phokas (987–89); 6,000 troops; marriage to Anna on condition of baptism | Verified | Arab sources agree on the broad story |
| Cherson captured 988; baptism there; Church of the Tithes 989 | Verified as DEBATED — FIXED | Baptism 987/988/989; Korsun legend called apocryphal by some |
| Rurik 862 / Oleg Kiev 882 | Verified (Primary Chronicle); alt. Novgorod chronicle | |
| Igor attacks on Constantinople 941 and 944 | Not verified in search | Standard (other sources: 907/911 Oleg) |
| Olga baptised 957 | Not verified | |
| Sviatoslav killed by Pechenegs 972; skull cup | Killing verified; cup = legend | |
| Boris and Gleb killed by Sviatopolk 1015 | Verified | |
| Yaroslav won at Liubech 1016 and Alta 1019 | Verified — FIXED | |
