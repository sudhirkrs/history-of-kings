# Ep 5 — Rajaraja Chola: The Emperor Who Ruled the Waves

## 1. HOOK (0:00–0:50)
In the year 1010, in the city of Thanjavur in southern India, a giant temple tower was completed. It rises about sixty-six metres, and its top stone is carved from a single block. Whether that block weighs eighty tons, as people often say, or less, it was lifted high into the air about a thousand years ago, with no cranes and no engines.
*Visual: Brihadisvara temple vimana in golden light*
The king who ordered this was Rajaraja Chola. His army conquered the south, his navy crossed the sea to Sri Lanka, and his empire became one of the strongest in the Indian Ocean world. In this video, we will see how the Cholas came back from near-oblivion, what Rajaraja conquered, how he ruled, and why his great temple still stands.
*Visual: map of the Chola empire reaching Sri Lanka and the Maldives*

## 2. THE CHOLAS BEFORE RAJARAJA (0:50–3:30)
The Cholas are one of the oldest named dynasties in India. Ashoka's own edicts, in the third century BCE, mention the Cholas, the Pandyas and the Cheras as independent kingdoms in the far south. The Sangam poems, composed in Tamil during the first centuries CE, praise Chola kings like Karikala.
*Visual: Ashoka edict naming the Chola country, Sangam poetry palm leaf*
But then the Cholas faded. From about the sixth century, the Pallavas of Kanchipuram and the Pandyas of Madurai dominated the Tamil country. The Cholas survived as minor chiefs.
In the middle of the ninth century, a Chola ruler named Vijayalaya took the city of Thanjavur around 850 CE, and began a revival. His descendants, Aditya I and Parantaka I, steadily expanded. They defeated the Pallavas and fought the Pandyas.
*Visual: map showing Chola revival from Thanjavur outward*
But disaster came. In 949 CE, the Rashtrakuta king Krishna III, from the Deccan, defeated the Chola army at the battle of Takkolam, and killed the Chola crown prince. For about thirty years, the Cholas were weak, and ruled by a series of short-lived kings.
It was in this difficult time, in 985 CE, that a man named Arulmozhivarman took the throne. We know him as Rajaraja, which means King of Kings.
*Visual: Takkolam battle, then a coronation of Rajaraja in 985*

## 3. WHO WAS RAJARAJA? (3:30–5:30)
Rajaraja was born around the middle of the tenth century. Some scholars give 947 CE, but his birth year is not certain. He was the son of the Chola king Sundara Chola, also called Parantaka II, and queen Vanavan Mahadevi.
*Visual: royal family tree, Sundara Chola, Rajaraja, his sister Kundavai*
His elder sister Kundavai is a figure we know well. She is recorded in many inscriptions as a pious and powerful royal woman who made gifts to temples. There was also an elder brother, Aditya Karikala, who was killed in mysterious circumstances around 969 CE. Historians still debate who was behind it. Inscriptions hint at a conspiracy, but the case remains open.
*Visual: Kundavai portrait, palace intrigue silhouettes*
After Aditya Karikala's death, the throne should have gone to Rajaraja. But a cousin, Uttama Chola, ruled until 985. Some scholars think Rajaraja stepped aside willingly. Others think he was kept out. Whatever the reason, he took power in 985 CE, aged about thirty-eight, with long experience as a prince.
He ruled for twenty-nine years.

## 4. CONQUEST: SOUTH, WEST, AND ISLANDS (5:30–9:30)
Rajaraja's first goal was to restore the Chola core and defeat the neighbours who had troubled his family.
*Visual: map of Chola neighbours, Pandya, Chera, Ceylon*
His inscriptions boast of a victory at Kandalur Salai, a place on the Malabar coast, around 988 CE. Some historians say the enemy was the Chera king Bhaskara Ravi Varman, others think Kandalur was then held by the Pandyas. Either way, it showed that the Cholas could reach the western coast by sea.
He then defeated the Pandyas of Madurai, and brought them firmly under Chola rule. By about 993 CE, the three Tamil kingdoms were united under one power for the first time in centuries.
*Visual: cavalry and elephants, Pandya capital Madurai*
Later Chola inscriptions say he next turned to the Gangas of Mysore, who ruled the land to the north-west, and took much of southern Karnataka. He also won in the area of Vengi, in modern Andhra Pradesh, a rich land between the Krishna and Godavari rivers, and arranged for his daughter Kundavai II to marry a prince of the Eastern Chalukya house. This tied the two dynasties together.
*Visual: expansion map, Mysore plateau, Vengi*
Now came the big one: Sri Lanka. The island's northern kingdom of Anuradhapura was ruled by the Sinhalese king Mahinda V. Around 993 CE, Rajaraja sent a powerful army across the narrow sea. The Chola forces conquered the north of the island, destroyed the city of Anuradhapura and, according to Chola records, set up a new capital at Polonnaruwa, which they renamed Jananathamangalam. The conquered north became a Chola province.
*Visual: Chola ships crossing the Palk Strait, Anuradhapura in flames*
The Sri Lankan chronicle Culavamsa, written by Buddhists, remembers this conquest as destructive and cruel. The Chola inscriptions present it as a glorious victory. As always, it depends on who writes the story.
His last big naval act was the conquest of the Maldives, which the inscriptions call the twelve thousand ancient islands. His son would later take the navy even further.
*Visual: islands of the Maldives, Chola fleet*

## 5. THE CHOLA STATE (9:30–12:30)
Rajaraja did not just conquer; he organised. He ordered a land survey, around 1000 CE. Officials measured fields, assessed their quality and set the tax. The survey was recorded in inscriptions, and historians see it as a systematic recording of land and revenue.
*Visual: measuring rods, village land survey, ledgers*
The basic unit of the Chola state was the nadu, a district, and within it were villages governed by assemblies. At Uttaramerur, near Kanchipuram, a stone inscription from about 920 CE describes how the village assembly was elected. Candidates had to own land, be of a certain age, roughly between thirty-five and seventy, and know the scriptures, and names were drawn by lot from pots. There were rules to disqualify those who failed to submit accounts, took bribes or committed crimes.
*Visual: Uttaramerur hall, pots with palm-leaf ballots*
This is not democracy as we know it today; the assembly was limited to landowning Brahmin men. But it shows a surprisingly organised system of local self-government, a thousand years ago.
The army was well organised too. Inscriptions mention royal elephant corps, cavalry and infantry bodies, and special regiments that guarded the king. There was also a navy, the key to the Chola success overseas.
*Visual: Chola army structure, naval ship*
Trade flourished. Tamil merchant guilds, like the Ayyavole Five Hundred and the Manigramam, traded across the Indian Ocean. Chinese records mention a Chola embassy to the Song court in 1015, in the last year of Rajaraja or the first of his son Rajendra, depending on the source. It suggests that Chola traders were active in the South China Sea.
*Visual: trade routes to Southeast Asia and China, merchant ship*
Rajaraja also gave Nagapattinam on the coast to the Sailendra king of Srivijaya, to build a Buddhist monastery, the Chudamani Vihara. The copper plates recording this are known as the Anaimangalam grant, issued under his son Rajendra. It shows a king who supported different religions, even though he himself was a devoted Shaiva.

## 6. THE GREAT TEMPLE (12:30–15:30)
Rajaraja's greatest monument is the Brihadisvara temple at Thanjavur, also called the Rajarajesvaram. Work began about 1003 or 1004 CE, and an inscription tells us that the king himself laid the final pinnacle in 1010.
*Visual: temple under construction, architect's plan*
The temple's main tower, the vimana, rises to somewhere between 63 and 66 metres, depending on who measures, in thirteen levels. The topmost capstone is a single piece of granite, often said to weigh around 80 tons, though the exact figure is uncertain. How was it lifted? A popular tale says an earth ramp of several kilometres was built, but historians say that there is no real evidence for this. Another view suggests a ramp at the temple site itself. The truth is that we do not know exactly.
*Visual: vimana cross-section, ramp diagram labelled debated*
The granite had to be brought from quarries kilometres away, since the area around Thanjavur is on a river delta without much stone. Its architect, according to an inscription, was a man named Kunjara Mallan Rajaraja Perunthachchan.
The temple inscriptions are priceless. They list the temple's donations: gold, silver and jewels. They name more than 400 temple dancers, who were assigned houses near the temple, and musicians, accountants, cooks, garland-makers and watchmen. It was as much an economic institution as a religious one, a major employer for the whole city. Musicians are listed too, with the number given as 240 or about 250.
*Visual: temple inscription walls, dancers, musicians*
The inscriptions also mention a long list of bronze images donated to the temple, and the Chola bronzes, especially the dancing Shiva, Nataraja, are among India's greatest art. The temple is a UNESCO World Heritage Site.
*Visual: Nataraja bronze, UNESCO plaque*

## 7. THE END AND THE NEXT GENERATION (15:30–17:00)
Rajaraja died around 1014 CE. He had named his son Rajendra as co-ruler a few years before, to make sure the transition went smoothly.
*Visual: Rajaraja and Rajendra together*
Rajendra Chola would take the empire to even greater heights, with an expedition to the Ganges around 1021 and a naval attack on Srivijaya in Southeast Asia around 1025. He built a new capital, Gangaikonda Cholapuram, and his own temple.
*Visual: Rajendra's Ganges expedition map, Srivijaya naval raid*
The Cholas lasted until the thirteenth century, when the Pandyas resurged, and the empire faded by about 1279.

## 8. LEGACY AND DEBATE (17:00–18:30)
What did Rajaraja leave us? A united south, a strong navy, an efficient administration, and a temple that still stands. And an enormous number of inscriptions that let us follow his reign year by year, which is rare for a medieval Indian king.
*Visual: inscriptions covering temple walls*
Historians still debate several things. How centralised was the Chola state? Some, following Burton Stein, argued that it was a segmentary state with limited central control. Others, like K.A. Nilakanta Sastri, saw a powerful, centralised empire. The truth may lie in between.
They also debate the purpose of the Sri Lanka conquest, whether it was trade, security, or glory, and the extent of Chola naval power.
*Visual: two competing models drawn as diagrams*
Next, we go to the north of India, to the golden age of the Guptas, with the conqueror Samudragupta, sometimes called the Napoleon of India. Subscribe, and tell me in the comments which king you want after that.
*Visual: end screen*

## Fact-check flags
- [ ] Rajaraja crowned 985, died 1014; birth year uncertain (947?).
- [ ] Takkolam 949 CE; Aditya Karikala's death 969 CE; who killed him is unsolved.
- [ ] Kandalur Salai, Chera defeat; Pandya conquest; Ganga/Nolambavadi conquest.
- [ ] Sri Lanka conquest ~993; Polonnaruwa renamed Jananathamangalam; Culavamsa's view.
- [ ] Land survey of 1000 CE (his 16th year): check inscription.
- [ ] Uttaramerur inscriptions (c. 919–921 CE; under Parantaka I): process of choosing members.
- [ ] Brihadisvara: begun c. 1003–04, consecrated 1010; vimana 66 m, 13 tiers; capstone weight; architect name.
- [ ] 400 dancers (talichcheri pendugal), and details of temple staff.
- [ ] Chinese embassy 1015; Chudamani Vihara and Anaimangalam grant (finished under Rajendra).
- [ ] Rajendra's Ganges expedition ~1021, Srivijaya ~1025.

## Metadata
Title: Rajaraja Chola: The Emperor Who Built the Great Temple and Ruled the Seas
Hook: How the Cholas rose from near-oblivion to rule the south and the sea, and the story of Rajaraja, the Brihadisvara temple, and the Chola state.
Tags: Rajaraja Chola, Chola Empire, Brihadisvara Temple, Thanjavur, Rajendra Chola, South Indian history, Indian history, history of kings
Hashtags: #RajarajaChola #CholaEmpire #IndianHistory #HistoryOfKings
Sources:
- K.A. Nilakanta Sastri, The Cholas
- Burton Stein, Peasant State and Society in Medieval South India
- Y. Subbarayalu, South India under the Cholas
- Kenneth Hall, Trade and Statecraft in the Age of the Colas
- George Spencer, The Politics of Expansion: The Chola Conquest of Sri Lanka and Sri Vijaya

## Fact-check log
| Claim | Verdict | Notes |
|---|---|---|
| Reign 985–1014 CE | Verified | Kielhorn: accession June–July 985 |
| Born 947 CE | FIXED | Not confirmed; script now says birth year uncertain |
| Takkolam c. 948–49 CE vs Krishna III; crown prince killed | Verified | The prince killed was Rajaditya (Parantaka I's son), not Aditya Karikala |
| Aditya II (Karikala) killed c. 969; Uttama Chola ruled after | Verified | Murder unsolved |
| Kandalur Salai c. 988; opponent Chera Bhaskara Ravi | FIXED | Opponent disputed (Pandyas?) |
| Sri Lanka invasion 993, Mahinda V fled south, Polonnaruwa renamed Jananathamangalam | Verified (Wikipedia); renaming mainly in secondary sources | Chola control lasted to ~1070 |
| Brihadisvara built 1003–1010; vimana height | FIXED | Wikipedia 63.4 m; others 66 m |
| Capstone ~80 tonnes | Verified as ESTIMATE | How raised: unknown |
| Architect Kunjara Mallan Rajaraja Perunthachchan | Verified in secondary sources | |
| 400 temple dancers; ~240–250 musicians | Verified | Housing details from one secondary report |
| Land survey c. 1000 CE | Verified | "16th year" not verified |
| Uttaramerur inscriptions 919/921 CE (Parantaka I); lots from pots; age and land qualifications; disqualifications | Verified | Assembly of landowning Brahmin men — script FIXED; "barred from standing again" removed (not supported) |
| Embassy to China 1015 | FIXED | Wikipedia attributes it to Rajendra; script now says either |
| Chudamani Vihara request c. 1006; Anaimangalam plates | Verified | Plates bear Rajendra's seal; script FIXED |
| Rajendra: Ganges expedition (Mahipala), Gangaikonda Cholapuram, Srivijaya raid 1025–26 | Verified | Motive unknown |
| Burton Stein "segmentary state" vs Nilakanta Sastri | Not searched | Standard historiography |
