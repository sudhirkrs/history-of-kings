# Ep 38 — Yaroslav the Wise: The Prince Who Gave Kiev Its Golden Age

## 1. HOOK (0:00–0:45)
In the eleventh century, the ruler of Kiev married his daughters to the kings of France, Norway and Hungary. His city had a great cathedral with gold mosaics, a Golden Gate, and a library. His people had a written law code. He was the grandfather, by marriage and blood, of half the royal families of Europe.
*Visual: Kiev's St Sophia, the Golden Gate, a map of royal marriages across Europe*
He is known as Yaroslav the Wise. Yet he came to power by civil war, he was lame, his own raid on Constantinople failed, and when he died his sons began fighting. This is the story of the prince who made Kiev a European capital, and the limits of what he built.
*Visual: Yaroslav portrait, Kievan Rus' map*

## 2. THE PRINCE OF NOVGOROD (0:45–2:15)
Yaroslav was a son of Vladimir the Great, the prince who brought Christianity to the Rus'. Sources give his birth as 978 or 980. His father sent him to rule Novgorod, the great northern city. As he grew older, he began to resist his father's control, and by 1015 he refused to send the tribute that Novgorod owed to Kiev. Vladimir was preparing for war against his own son when he died in July of that year.
*Visual: Novgorod, Vladimir's death*
Then came the fight for the throne. Sviatopolk, another son of Vladimir, took Kiev and had his half-brothers Boris and Gleb murdered. They became the first saints of the Russian church. Yaroslav, with help from Novgorod and from Scandinavian mercenaries, fought Sviatopolk. In 1016, he beat him at Liubech, and drove him out of Kiev. Sviatopolk returned in 1018 with Polish troops and the support of his father-in-law, King Boleslaw of Poland, and took Kiev again. Yaroslav had to flee.
*Visual: Boris and Gleb, battle at Liubech*
Finally, in 1019, at the river Alta, Yaroslav defeated Sviatopolk, who was supported by the Pechenegs, steppe nomads. The date and year of the battle vary in sources, but 1019 and 24 July are most often given. Sviatopolk fled and died. Yaroslav was the Grand Prince of Kiev. He married the daughter of the Swedish king, Ingegerd, around the same time.

## 3. SHARING THE LAND (2:15–3:00)
But he did not rule all of Rus'. Another brother, Mstislav, ruled the distant outpost of Tmutarakan on the Black Sea, and then took Chernigov. In 1024 Mstislav defeated Yaroslav in a battle at Listven. The two brothers made a peace. The sources, mainly a legendary chronicle account, say that they divided the Rus' along the Dnieper river. Yaroslav kept the west, with Kiev on the right bank, and Mstislav the east, with Chernigov.
*Visual: map: Rus' divided along the Dnieper*
This lasted until Mstislav died in 1036. Then Yaroslav ruled the whole of Rus', and in the same year defeated the Pechenegs, who had attacked Kiev. This victory ended the Pecheneg threat to the city.
*Visual: Pecheneg attack on Kiev, victory*

## 4. THE BUILDER OF KIEV (3:00–3:57)
After his victory over the Pechenegs, Yaroslav set about turning Kiev into a capital to rival Constantinople. According to tradition, he built the Cathedral of St Sophia in 1037, on the site of the victory over the Pechenegs. It was named after Hagia Sophia in Constantinople. Its interior, with its mosaics and frescoes, is still one of the major monuments of the age.
*Visual: St Sophia in Kiev, mosaics*
He also built the Golden Gate, the main entrance to the city, which has not survived in its original form. The city was fortified with new walls. He founded monasteries, including the Monastery of the Caves, which would become the centre of Russian monastic life.
He supported education. The chronicle says that he gathered scribes to translate Greek books into Slavonic, and set up a library. Historians accept that book translation grew under him.
*Visual: scribes, library, Monastery of the Caves*

## 5. LAW (3:57–4:38)
Yaroslav's name is attached to the first East Slavic law code, the Russkaya Pravda, the Rus' Justice. The details are debated. Historians believe the oldest part, called the Pravda of Yaroslav, began as a collection of customs and rulings in his time, and was added to by his sons and grandsons. Britannica says the codification began under him.
*Visual: law code manuscript*
The code fixed rules for murder, theft and injuries. It was notable for allowing fines for killing instead of blood feuds, and its use of money compensation. It tells us about the society of the time: free people, dependent peasants, and slaves.

## 6. A FAMILY OF KINGS (4:38–5:37)
Yaroslav's own family helps explain his place in Europe. His mother was Rogneda of Polotsk, one of Vladimir's wives. His queen, Ingegerd, a daughter of the king of Sweden, married him in 1019, and he gave her the town of Staraya Ladoga as a wedding gift. They had many children.
*Visual: family tree, Ingegerd, Staraya Ladoga*
The daughters carried the name of Kiev across the continent. Elisiv, or Elizabeth, married the Norse adventurer Harald Hardrada, who won her hand through his service and fame in the Byzantine Empire, and later became king of Norway. Anastasia married the future King Andrew I of Hungary. Anna married King Henry I of France, a widower without a son, who sought an ally and an heir. The wedding took place at Reims, in May 1051. Sources disagree about Anna's birth year, and about how she got to France, but she gave Henry sons.
*Visual: Harald Hardrada, Reims Cathedral, Anna of Kiev*

## 7. DIPLOMACY AND DAUGHTERS (5:37–6:38)
Yaroslav built ties with the courts of Europe. As we saw, his daughters married into the royal families of Norway, France and Hungary. His sons married into the Polish, German and Byzantine houses. In 1043, his son Vsevolod was married to a daughter of the Byzantine emperor.
*Visual: marriage network map, Anna of Kiev, Elizabeth*
Anna of Kiev became Queen of France. She is known to have signed documents in Cyrillic letters when the French court could not read, and to have been one of the few literate people in the French court. The detail is often repeated in popular histories, but the sources are late.
Not everything went well. In 1043, Yaroslav sent a fleet against Constantinople, led by his son Vladimir and the general Vyshata. The fleet was defeated, and the campaign has been called a failure. Yet he managed to get a peace treaty with the Byzantines, including the royal marriage.
*Visual: Rus' fleet at Constantinople, defeat*

## 8. DEATH AND THE TESTAMENT (6:38–7:28)
Yaroslav died in February 1054. Most sources give 20 February, though Britannica says 2 February. He was buried in St Sophia, in a marble sarcophagus that survives. The Norse sagas call him Jarisleif the Lame. The examination of his remains in the 1930s is said to have confirmed that he had a leg injury, though the sources for that are second-hand.
*Visual: the sarcophagus*
Before dying, he divided Rus' among his five sons. He told them to obey the eldest, Izyaslav, who took Kiev. Izyaslav's brothers received Chernigov, Pereyaslavl, and other cities. He asked them to live in peace. They did not. After his death, a long series of wars began among his descendants, and the unity of Rus' faded in the following century.
*Visual: division of lands among five sons, civil war*

## 9. LEGACY AND DEBATE (7:28–8:27)
Yaroslav is remembered as the high point of Kievan Rus'. He is claimed by Russia, Ukraine and Belarus alike, and in modern Ukraine his portrait appears on banknotes. The nationalist claims are anachronistic, since these nations did not yet exist. What is clear is that, in his time, Kiev was one of the major cities of Europe, and the Rus' were connected with the courts of the continent.
*Visual: Kiev in the 11th century, modern portrait on banknote*
Historians debate several things. How much of the law code goes back to him? How reliable are the chronicle accounts of Alta and Listven? Was he really called Wise in his time, or later? And was his succession plan a cause of the later breakup?
*Visual: question cards*
Next, we cross to the Ottoman Empire, and the sultan who took Constantinople at the age of twenty-one: Mehmed the Conqueror. Subscribe, and tell me which king you want after that.
*Visual: end screen*

## Fact-check flags
- [ ] Born 978 or 980; died 20 Feb 1054 (Britannica: 2 Feb).
- [ ] Refused tribute to Kiev 1014/1015: NOT verified by this search.
- [ ] Liubech 1016 (verified); Sviatopolk's return 1018 with Boleslaw: NOT verified in this search.
- [ ] Alta 24 July 1019 (Wikipedia; 1018 or 1020 in other sources).
- [ ] Marriage to Ingegerd 1019 (Lumen); Yaroslav's first wife Anna: origin disputed (script no longer calls Ingegerd 'third').
- [ ] Listven 1024; Dnieper division; Mstislav d. 1035/1036 (verified, legendary account).
- [ ] Pecheneg defeat 1036; St Sophia 1037; Golden Gate (verified).
- [ ] Russkaya Pravda: begun under him (Britannica).
- [ ] Monastery of the Caves; translations; library: NOT verified.
- [ ] Daughters' marriages: Elizabeth–Harald; Anna–Henry I; Anastasia–Andrew I (verified).
- [ ] Anna of Kiev signing in Cyrillic: NOT verified; late sources.
- [ ] 1043 war: Vladimir and Vyshata; defeated; treaty and Vsevolod's marriage (verified).
- [ ] Testament: five sons; obey Izyaslav (verified); "Lame": sagas (verified; examination secondary).

## Metadata
Title: Yaroslav the Wise: The Prince Who Gave Kiev Its Golden Age
Hook: A civil war winner, a law-giver and the father-in-law of Europe's kings: the rise of Yaroslav the Wise, his Kiev, and the quarrel that followed him.
Tags: Yaroslav the Wise, Kievan Rus, Kyiv, St Sophia Cathedral, Russkaya Pravda, Anna of Kiev, medieval Europe, history of kings
Hashtags: #YaroslavTheWise #KievanRus #HistoryOfKings
Sources:
- The Russian Primary Chronicle, trans. Cross and Sherbowitz-Wetzor
- Simon Franklin and Jonathan Shepard, The Emergence of Rus 750-1200
- Janet Martin, Medieval Russia 980-1584
- Serhii Plokhy, The Origins of the Slavic Nations
- Martin Dimnik, The Dynasty of Chernigov

## Fact-check log
(Search-first drafting: facts were searched before writing; items below show what search confirmed. See factcheck/README.md for limits.)

| Claim | Verdict | Notes |
|---|---|---|
| Born 978 or 980; died 20 Feb 1054 (Britannica: 2 Feb) | Verified | |
| Liubech 1016; Alta 24 July 1019 (other years 1018/1020) | Verified | Sviatopolk's 1018 return with Boleslaw: not verified |
| Refused tribute 1014/15 | NOT verified | |
| Ingegerd married 1019 | Verified — FIXED "third wife" | Yaroslav's first wife Anna's origin disputed |
| Listven 1024; division along the Dnieper; Mstislav d. 1035/36 | Verified (legendary account) | |
| Pecheneg victory 1036; St Sophia 1037; Golden Gate | Verified | |
| Russkaya Pravda begun under him | Verified (Britannica) | |
| Monastery of the Caves; library/translations | NOT verified | |
| Daughters: Elizabeth–Harald; Anna–Henry I; Anastasia–Andrew I | Verified | Anna signing in Cyrillic: not verified |
| 1043 Constantinople raid failed; treaty; Vsevolod married | Verified | |
| Testament: five sons, obey Izyaslav; civil war | Verified | "Lame" per sagas; examination secondary |

## Extension pass (added: A Family of Kings)
| Claim | Verdict | Notes |
|---|---|---|
| Mother Rogneda of Polotsk | Verified (search) | |
| Ingegerd married 1019; Staraya Ladoga as wedding gift | Verified (search) | |
| Elisiv m. Harald Hardrada (won her via Byzantine service); Anastasia m. Andrew I; Anna m. Henry I | Verified (search) | |
| Anna–Henry wedding at Reims, 19 May 1051 | Verified (one source) | Anna's birth year disputed (1024/5, 1032, 1036); not stated |
| Anna bore Henry sons | NOT verified in this pass | Standard (Philip I); check |
