# Ep 6 — Samudragupta: The Conqueror Who Played the Veena

## 1. HOOK (0:00–0:50)
There is a stone pillar in the city of Prayagraj, in northern India. Its oldest writing was ordered by Ashoka. But carved over it, in elegant Sanskrit verse, is a second inscription: a long poem praising a king who defeated nine rulers in the north, captured twelve kings in the south, forced the borders of his empire to pay tribute, and made foreign kings send him gifts.
*Visual: the Allahabad pillar, close-up of Ashokan edict and the later Sanskrit lines*
That king was Samudragupta, the second great ruler of the Gupta dynasty. Some historians have called him the Napoleon of India. But there is another side to him. The same king is shown on his coins, sitting calmly, playing the veena, an Indian stringed instrument.
*Visual: gold coin of Samudragupta playing the veena*
In this video, we will follow the soldier, the poet, and the politician. And we will look carefully at the one source that tells most of the story, because it was written to praise him.

## 2. INDIA AFTER THE MAURYAS (0:50–3:20)
After the Maurya Empire fell around 185 BCE, northern India broke into pieces. The Shungas ruled in Magadha. Greek, Shaka, Parthian and Kushan rulers took the north-west. In the south, the Satavahanas held the Deccan. For about five hundred years, no single power ruled most of the subcontinent.
*Visual: map of fragmented India, Kushans, Satavahanas, Shakas*
By the third century CE, the Kushan power had weakened, and many small kingdoms and tribal republics ruled the Gangetic plain. In the region of Magadha, a local ruler named Gupta, and then his son Ghatotkacha, started a small dynasty.
The real founder of Gupta power was the third ruler: Chandragupta I, who began to rule around 319 or 320 CE. He is not the same as Chandragupta Maurya, so we must keep them apart. This Chandragupta made a smart marriage with Kumaradevi, a princess of the Licchavis, a respected old clan whose territory lay north of the Ganges.
*Visual: wedding of Chandragupta I and Kumaradevi, Licchavi territory map*
Coins issued in their joint names show how important this alliance was. Their son, born around the early fourth century, was Samudragupta.
*Visual: king-and-queen coin type*

## 3. A CONTESTED SUCCESSION (3:20–5:00)
Samudragupta's accession is itself a little mysterious. The inscription says that his father, in front of the court, embraced him and said: protect the earth. The other princes, it says, looked pale.
*Visual: court scene, the king embracing a young prince, other princes watching*
This suggests that he was chosen over his brothers. Some later evidence, including a coin type of a king named Kacha, has led historians to wonder whether there was a rival who briefly claimed the throne. Kacha's coins look similar to Samudragupta's, and some scholars think Kacha was Samudragupta's own brother, or even an early name of Samudragupta. The evidence is thin, and scholars still disagree.
*Visual: Kacha coin, question marks*
What we can say is that around 335 CE, Samudragupta took the throne, and that he soon showed himself to be a ferocious military leader. He would rule for about forty years.

## 4. THE ALLAHABAD PRASHASTI (5:00–7:00)
Before we look at his conquests, we need to understand our main source.
The inscription on the Allahabad pillar is called a prashasti, a poem of praise. It was composed by Harisena, a court poet and minister. It describes the king's conquests in great detail, in a mix of verse and prose.
*Visual: Sanskrit text, translation overlay*
This is a rare gift: a long, detailed list of a king's wars. But there is also a danger. Court poets exaggerate. The poem does not mention any defeat. It uses flattering language about the king's virtues. A Gupta ruler would never have allowed it to say anything else.
So historians use the prashasti carefully. They compare it with coins, other inscriptions and later sources. Where they agree, we can be fairly confident. Where only the prashasti speaks, we have to treat it as the king's own version of events.
*Visual: scale comparing royal propaganda and independent evidence*

## 5. THE CONQUESTS (7:00–11:30)
The prashasti arranges his wars in categories, depending on how the opponents were treated.
*Visual: map with four colour zones*
First, the kings of Aryavarta, the Gangetic plain. The poem says Samudragupta violently uprooted them and annexed their lands. It names nine of them, including Rudradeva, Matila, Nagadatta, Chandravarman, Ganapatinaga, Nagasena, Achyuta, Nandin and Balavarman. Some of these are known from other evidence. Chandravarman may be the king named on the Susunia inscription in Bengal.
*Visual: nine names appearing on map across the plain*
Second, the forest kingdoms. The poem says he made all the forest chiefs his servants. This probably covers the hill and forest regions of central India.
Third, the Dakshinapatha, the southern route. Here the story changes. In the south, the poem says, he captured twelve kings and then let them go, restoring their kingdoms in return for tribute. The names include Mahendra of Kosala, Vyaghraraja of Mahakantara, and, far south, Vishnugopa of Kanchi, the Pallava capital. This is a campaign down the east coast, almost to modern Chennai.
*Visual: campaign route down the east coast to Kanchipuram*
Why release them? Historians think Samudragupta understood that he could not rule the far south from Pataliputra. It was smarter to defeat them, take their wealth and make them tributaries. The prashasti puts it with a famous phrase: capture, then release, and show favour.
Fourth, the frontier. Border kingdoms like Samatata in Bengal, Kamarupa in Assam and Nepal, and many tribal republics of Punjab and Rajasthan, including the Malavas, Yaudheyas and Madrakas, paid tribute, obeyed orders and attended in person.
*Visual: frontier kingdoms icons, tribal republics*
Finally, foreign rulers. The inscription says that the Daivaputra Shahi Shahanushahi, which probably means the Kushan kings, the Shakas and the king of Sri Lanka, brought presents, offered their daughters and asked for royal seals. Historians read this as flattering language for simple diplomatic ties. The Chinese pilgrim Xuanzang, writing centuries later, records that the Sri Lankan king Meghavarna sent an envoy with gifts, asking permission to build a monastery at Bodh Gaya for Sri Lankan pilgrims, and the request was granted. Xuanzang's wording suggests the Gupta court may have seen the gifts as tribute.
*Visual: envoys bringing gifts, Sri Lankan monastery at Bodh Gaya*
How big was the empire? At its widest, the direct Gupta territory included the Gangetic plain from Punjab to Bengal, with the surrounding kingdoms as vassals. It was not as big as the Maurya Empire, but it was well governed.

## 6. THE KING WHO PLAYED THE VEENA (11:30–13:30)
The Napoleon comparison was made by the British historian Vincent Smith, in his Early History of India, first published in 1904. Many modern historians find it misleading. Samudragupta was not a conqueror who fought for the sake of war. He was a king who combined conquest with careful diplomacy.
*Visual: Vincent Smith's book, then a scale of war and diplomacy*
His coins show another side. His gold coins come in several types. One shows him as an archer with a bow. Another shows him holding a battle-axe. One shows him slaying a tiger, a rare type. And one shows him sitting on a couch, playing the veena.
*Visual: four coin types in a row*
The prashasti claims that he put the gods of music to shame by his skill, and that he was a poet who wrote verses worthy of being called the king of poets. No poem by him survives. But the claim is consistent with the music on his coins.
He also performed the Ashvamedha, the great horse sacrifice, a Vedic ritual that proved a king's supreme power. Gold coins show a horse standing in front of a sacrificial post, which numismatists read as marking the horse sacrifice.
*Visual: sacrificial horse, coin with Ashvamedha legend*
This tells us something about the Guptas. They were Hindu rulers who revived Vedic rituals. They worshipped Vishnu, and called themselves Parama Bhagavata, great devotees of Vishnu. But they also supported Buddhist and Jain institutions, as the Sri Lankan monastery shows.

## 7. HOW HE RULED (13:30–15:30)
How did the Gupta state work? It was different from the Mauryan state. It was less centralised.
*Visual: concentric circles, core, vassals, frontier*
In the core areas, the king ruled directly through provinces called bhuktis and districts called vishayas, with officers like the kumaramatya. In outer regions, local kings accepted Gupta overlordship, paid tribute and kept their own courts. This was a flexible empire, less costly to run than the Mauryan one.
Gold coins, called dinaras, were struck in great numbers, and they show the empire's wealth. This was possible because of trade with Rome, which had boomed in the earlier centuries, and then continued across the sea with Southeast Asia. Pataliputra remained the capital.
*Visual: gold dinara, ships, Pataliputra*
The Guptas also supported learning. Their successors would see science and literature flourish. The astronomer Aryabhata was born in 476 CE. The poet Kalidasa is usually placed in the time of Samudragupta's son. This is why the era is often called a golden age. Modern historians prefer to call it a classical age, and to remember that it had its problems, such as limited rights for lower castes and women.
*Visual: Aryabhata, Kalidasa manuscript*

## 8. DEATH AND SUCCESSION (15:30–17:00)
Samudragupta died around 375 CE. The next ruler is a puzzle.
Later sources, including a lost Sanskrit play called the Devichandraguptam, mention an elder son named Ramagupta, who agreed to give his wife to a Shaka enemy, and was overthrown by his brother, Chandragupta II, who killed the Shaka king in disguise. The play is lost, and only quotations survive. Some coins and inscriptions suggest a king named Ramagupta existed. Historians remain divided on whether the story is true.
*Visual: manuscript fragment, two brothers*
What is certain is that Chandragupta II, also called Vikramaditya, took the throne around 380 CE. He defeated the Shakas of western India and took Gujarat, which brought the Guptas a western sea coast with rich ports. Under him the Gupta empire reached its peak.
*Visual: map of Chandragupta II's conquests*
The Guptas ruled for about two more centuries. Their end came in the late fifth and sixth centuries, under attacks from the Hunas, or Alchon Huns, and the break-up of the empire.

## 9. LEGACY AND DEBATE (17:00–18:20)
Samudragupta's reputation depends on a single source. Without the Allahabad prashasti, we would know little about him. He is a reminder that history is often what kings wanted written.
*Visual: pillar again*
Historians debate several questions. Was there a succession struggle? How much of the prashasti is exaggeration? Did the Gupta kings truly rule the lands listed, or did they just raid and take tribute? And is the golden age idea fair?
Next, we go south again, to the Vijayanagara Empire, and the greatest of its kings, Krishnadevaraya. Subscribe, and tell me in the comments which king you want after that.
*Visual: end screen*

## Fact-check flags
- [ ] Reign about 335–375 CE; Chandragupta I from ~319/320 CE (Gupta era).
- [ ] The nine Aryavarta kings, twelve Dakshinapatha kings, spellings and identifications.
- [ ] Susunia inscription and Chandravarman (identification uncertain).
- [ ] Kacha coins: scholarly debate; do not state as fact.
- [ ] Meghavarna's mission: Xuanzang (c. 637 CE); Wang Xuance version not confirmed.
- [ ] The lists of nine Aryavarta kings and twelve southern kings: not confirmed by search; check a translation of the Prayaga Prashasti.
- [ ] "Napoleon of India": Vincent Smith, Early History of India, 1904.
- [ ] Coin types: archer, battle-axe, tiger-slayer, lyrist, Ashvamedha.
- [ ] Ramagupta/Devichandraguptam story: label as debated.
- [ ] Aryabhata b. 476 CE; Kalidasa dating is uncertain.

## Metadata
Title: Samudragupta: The Gupta Conqueror Who Played the Veena
Hook: A conqueror, a poet and a politician: Samudragupta and the pillar inscription that praises his wars. What it tells us, and what it may exaggerate.
Tags: Samudragupta, Gupta Empire, Allahabad Pillar, Prayaga Prashasti, Chandragupta II, Indian history, ancient India, history of kings
Hashtags: #Samudragupta #GuptaEmpire #IndianHistory #HistoryOfKings
Sources:
- J.F. Fleet / D.C. Sircar, Select Inscriptions Bearing on Indian History and Civilization (Allahabad Pillar)
- R.C. Majumdar and A.S. Altekar (eds.), The Vakataka-Gupta Age
- Upinder Singh, A History of Ancient and Early Medieval India
- Romila Thapar, Early India
- Allan, Catalogue of the Coins of the Gupta Dynasties

## Fact-check log
| Claim | Verdict | Notes |
|---|---|---|
| Reign c. 335–375 CE | Verified (approx.) | Other listings 344–378 |
| Father Chandragupta I, mother Kumaradevi (Licchavi); king-and-queen coin | Verified | Some say the coin was issued by Samudragupta as commemoration |
| Prashasti by Harisena, Sanskrit, ~33 lines | Verified | |
| Nine Aryavarta kings and twelve southern kings (names) | NOT verified by search | Names are from memory of the standard translation (Fleet/Sircar); check |
| Kacha as brother/rival | Debated | Wikipedia: "possibly Kacha" |
| Ramagupta / Devichandraguptam (Vishakhadatta) | Partly | Sources say Vishakhadatta has Ramagupta as successor; play lost |
| Meghavarna's Bodh Gaya mission | Verified | Xuanzang; script FIXED to attribute to him |
| "Napoleon of India" — Vincent Smith 1904 | Verified attribution | Criticism not searched — wording softened |
| Coin types: lyrist, archer, battle-axe, tiger-slayer (rare), Ashvamedha | Verified | Legend text varies — specific legend removed |
| Chandragupta II c. 375/380–415; defeated Shakas c. 395 | Verified | |
| Aryabhata b. 476; Kalidasa dating uncertain | Verified | |
| Hunas weakened empire; end c. 550 | Verified | |
