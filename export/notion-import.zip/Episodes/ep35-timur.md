# Ep 35 — Timur: The Lame Conqueror

## 1. HOOK (0:00–0:49)
In December 1398, the Sultan of Delhi marched out of his city with an army and war elephants to face an invader from Central Asia. The invader's army destroyed his, and then entered Delhi. In the days that followed, one of the richest cities in the world was plundered and ravaged.
*Visual: Delhi's walls, elephants, burning city*
The conqueror was Timur, known in the West as Tamerlane, from Timur the Lame. He was a man who rose from a minor chief in Central Asia to rule an empire stretching from Delhi to Anatolia. He founded no lasting state, he built towers of skulls, and he filled his capital Samarkand with some of the most beautiful buildings in Asia. This is the story of Timur.
*Visual: Timur portrait, map of his conquests*

## 2. FROM CHIEFTAIN TO AMIR (0:49–2:11)
Timur was born in 1336 at Kesh, now Shahrisabz in Uzbekistan, about 80 kilometres south of Samarkand. His family belonged to the Barlas tribe, a Turkic-Mongol people, who were minor nobles under the khans of the Chagatai line, descended from Genghis Khan's son.
*Visual: Kesh, Barlas tribe, Chagatai khanate*
By the 1360s the Chagatai khanate was broken into warring factions. Timur became a military leader in this chaos. In his youth he received a leg injury, either from an arrow or in a fight with sheep thieves, according to different stories, that left him with a permanent limp. His enemies called him Timur-e Lang, Timur the Lame, which became Tamerlane in European languages. When Soviet scientists opened his tomb in 1941, they found evidence of old leg wounds, and judged that he stood about 172 centimetres tall.
*Visual: Timur on a horse, a limp, skeleton study*
He rose by skill and betrayal. He allied with his brother-in-law Amir Husayn, then turned on him. By 1370 he controlled Transoxiana, the land between the Oxus and Jaxartes rivers. He did not take the title of khan, since he was not a descendant of Genghis Khan. Instead, he ruled in the name of a puppet khan, and called himself Amir, meaning commander. He made Samarkand his capital.

## 3. THE CONQUESTS (2:11–3:04)
For the next thirty years, Timur was almost always at war.
*Visual: animated map of campaigns*
He conquered Khwarezm and Persia in the 1380s. His method was to offer a city the chance to surrender and pay. If it resisted, it was sacked. At Isfahan in 1387, the city first surrendered, then its people rose up and killed some of his tax collectors. Timur ordered a massacre. Estimates of the dead range from seventy thousand to two hundred thousand, and eyewitnesses reported pyramids of heads, around thirty of them with fifteen hundred heads each. Chroniclers of the time wrote the figures, and many historians think they are inflated, but the terror was real.
*Visual: Isfahan 1387, towers of skulls, labelled estimates uncertain*
In the north, his great enemy was Tokhtamysh, khan of the Golden Horde, and that war needs its own section.
*Visual: map of Timur's campaigns*

## 4. THE WAR WITH TOKHTAMYSH (3:04–3:52)
Timur's most dangerous enemy in the north was once his friend. Tokhtamysh, a prince of the Golden Horde, fled to Timur, and in 1378 with Timur's help took the throne of the White Horde. Then he turned against his patron. The war between them ran, with pauses, from 1386 until 1395. On 18 June 1391, at the river Kondurcha, in the steppes of what is now Russia, Timur's army met the Horde. After a hard fight, a sudden frontal attack put the Horde's troops to flight. Four years later, on the Terek, Timur destroyed Tokhtamysh's power, and his troops devastated the Golden Horde's cities, including its capital Sarai and Astrakhan. The Horde never fully recovered.
*Visual: steppe battle, Tokhtamysh, the ruins of Sarai*

## 5. THE SACK OF DELHI (3:52–5:04)
In 1398, Timur turned to India. His reason was partly money. The Delhi Sultanate under the Tughluq dynasty was weak and divided. His stated reason was that the sultan was too tolerant of the Hindus. His army crossed the Indus at Attock in September.
*Visual: crossing the Indus, march across the Punjab*
On the way, he is said to have executed a large number of prisoners, one hundred thousand, according to his own memoirs, because he feared they would rise up during the battle. Historians doubt this number but accept that prisoners were killed.
Near Delhi, on 17 December 1398, he defeated Sultan Nasir-ud-din Mahmud Shah, who fled. Timur entered the city, and for several days, it was sacked. Many inhabitants died or were enslaved. He took skilled craftsmen back to Samarkand, to work on his buildings. He stayed in Delhi for about two weeks, then moved on. He had not come to rule India, and left a ruined city and a dead empire. The Tughluqs never recovered. Decades later, Babur, Timur's descendant, would use Timur's invasion as a reason to claim India.
*Visual: battle of Delhi, sacked streets, craftsmen led away*

## 6. SYRIA AND THE HISTORIAN (5:04–5:56)
Before Ankara, Timur turned on the Mamluk sultanate of Egypt and Syria. In November 1400 his army took Aleppo. The Mamluk army, under the young sultan Faraj, retreated to Egypt in January 1401, leaving Damascus exposed. One man was stranded inside the city: the great North African historian Ibn Khaldun, who was visiting. He met Timur several times over about a month, in his camp. They talked about history and about the lands of the Maghreb. Timur tried to keep him in his service, and Ibn Khaldun declined. Timur had already decided the fate of the city. His troops plundered Damascus for days, and fire spread, damaging the great Umayyad Mosque. Timur left in mid-March 1401. Death tolls for the city vary widely in the sources.
*Visual: Aleppo, Ibn Khaldun and Timur, burning Damascus*

## 7. THE OTTOMANS AND THE END OF BAYEZID (5:56–7:19)
After India, Timur marched west. In 1400 and 1401 he took Aleppo, Damascus, and in 1401 Baghdad. At Baghdad, his men are said to have piled tens of thousands of heads in towers; the figures given range from twenty thousand to ninety thousand.
*Visual: Aleppo, Damascus, Baghdad*
His great rival was the Ottoman sultan Bayezid I, called Yildirim, the Thunderbolt, who had beaten crusaders at Nicopolis in 1396, and who was besieging Constantinople. On 28 July 1402 (20 July in some sources), at Ankara, Timur's army defeated the Ottoman forces. Bayezid's army had marched in the heat, and Timur had cut off their water supply. Some of Bayezid's own vassals changed sides. Bayezid was captured, the only Ottoman sultan ever taken prisoner by an enemy.
*Visual: Battle of Ankara, Bayezid captured*
A famous story says Timur kept Bayezid in an iron cage and used him as a footstool. Historians doubt it. Writers from Timur's own court say that Bayezid was treated well, and that Timur mourned his death. The cage story appears first in the account of one hostile writer, Ibn Arabshah, and gained popularity later. Bayezid died in captivity in 1403.
After Ankara, the Ottoman state fell into a civil war, and Constantinople got half a century more of life.

## 8. THE BUILDER OF SAMARKAND (7:19–8:02)
Timur's other face was a patron of buildings. The craftsmen he forced to Samarkand from conquered lands built mosques, palaces and gardens. The huge Bibi-Khanym Mosque, and his tomb, Gur-e-Amir, which means Tomb of the Ruler, were made by them. Samarkand, with its blue-tiled domes, became one of the great cities of the world.
*Visual: Samarkand's blue domes, Bibi-Khanym Mosque, Gur-e-Amir*
His grandson Ulugh Beg, who later ruled Samarkand, was an astronomer and built a large observatory.
Timur was said to have admired learning. He had lively conversations with scholars. He spoke Turkic and Persian. But he rarely spent more than a few months in his capital before the next campaign.

## 9. DEATH AND CURSE (8:02–8:56)
In late 1404 Timur set out to invade Ming China. It was winter, he was about 68, and he fell ill at Otrar, the same city where the insult to Genghis Khan had begun. He died there in February 1405.
*Visual: Otrar in winter, Timur's last journey*
He was buried in Samarkand. His empire broke up within a generation, among his sons and grandsons. His descendant Babur would found the Mughal Empire.
In June 1941, a Soviet team led by Mikhail Gerasimov opened the tomb. A story spread that the tomb carried a curse, saying that whoever opened it would unleash a worse invader, and that two days later Nazi Germany invaded the Soviet Union. The story is a legend. Soviet researchers later said it was invented. Timur's remains were reburied with Islamic rites in 1942.
*Visual: opening the tomb, legend labelled*

## 10. LEGACY AND DEBATE (8:56–9:34)
Today, Timur is a national hero in Uzbekistan, with statues in Tashkent and Samarkand. In India, Iran, Turkey, and Russia he is remembered very differently.
Historians still debate his death tolls, which come from partisan court writers. They debate whether he was a builder of a state or only a conqueror, and how much of his story, such as the iron cage, was added later.
*Visual: question cards*
Next, we move to England, and a king who broke with Rome to marry again: Henry VIII. Subscribe, and tell me which king you want after that.
*Visual: end screen*

## Fact-check flags
- [ ] Born 1336 Kesh (Shahrisabz); Barlas tribe; "80 km south of Samarkand" (Britannica says ~50 miles): check.
- [ ] Lameness: cause uncertain; 1941 exhumation: two healed wounds on right leg; 172 cm.
- [ ] Controlled Transoxiana by 1370: verified; title Amir with puppet khan: not verified.
- [ ] Isfahan 1387: 70,000–200,000; ~30 pyramids of 1,500 heads each (one source).
- [ ] Tokhtamysh broken 1395 (Terek/Kur river); 1391 not verified.
- [ ] Delhi: crossed Indus at Attock 24 Sept 1398; battle and sack 17 Dec 1398.
- [ ] 100,000 prisoners executed: Timur's memoirs (authenticity doubted): NOT verified.
- [ ] Aleppo/Damascus 1400–01; Baghdad 1401: 20,000–90,000 heads.
- [ ] Ankara 28 July 1402 (Britannica says 20 July); iron cage doubtful; Bayezid d. 1403.
- [ ] Nicopolis 1396: NOT verified.
- [ ] Death at Otrar Feb 1405 on the way to China: NOT verified.
- [ ] Gur-e-Amir opened 20 June 1941 (Gerasimov); curse = legend; reburied Nov/Dec 1942.
- [ ] Ulugh Beg observatory; Bibi-Khanym: NOT verified.

## Metadata
Title: Timur: The Lame Conqueror Who Sacked Delhi and Captured an Ottoman Sultan
Hook: From a minor chief in Central Asia to the master of an empire, Timur burned Delhi, beat the Ottomans at Ankara, and built Samarkand. Facts, figures and legends separated.
Tags: Timur, Tamerlane, Samarkand, Sack of Delhi, Battle of Ankara, Bayezid, Timurid Empire, Central Asian history, history of kings
Hashtags: #Timur #Tamerlane #HistoryOfKings
Sources:
- Beatrice Forbes Manz, The Rise and Rule of Tamerlane
- Justin Marozzi, Tamerlane: Sword of Islam, Conqueror of the World
- Ibn Arabshah, Tamerlane or Timur the Great Amir
- Ruy Gonzalez de Clavijo, Embassy to Tamerlane
- Sharaf ad-Din Ali Yazdi, Zafarnama

## Fact-check log
(Search-first drafting: facts were searched before writing; items below show what search confirmed. See factcheck/README.md for limits.)

| Claim | Verdict | Notes |
|---|---|---|
| Born 1336 Kesh (Shahrisabz); lame; 172 cm (1941 exhumation) | Verified | Cause of lameness uncertain |
| Controlled Transoxiana by 1370, Samarkand capital | Verified | Title Amir/puppet khan: not searched |
| Isfahan 1387: 70,000–200,000; skull pyramids | Verified as contested | Chroniclers partisan |
| Tokhtamysh broken 1395 | Verified | 1391: not verified |
| Delhi: Indus 24 Sept 1398; battle and sack 17 Dec 1398 | Verified | 100,000 prisoners killed (his memoirs): NOT verified |
| Baghdad 1401: 20,000–90,000 heads | Verified as contested | Damascus count not found |
| Ankara 28 July 1402 (Britannica: 20 July); Bayezid captured, died 1403; iron cage doubtful | Verified | Cage first in Arabshah |
| Otrar/death Feb 1405 | NOT verified | Standard |
| Gur-e-Amir opened 20 June 1941 (Gerasimov); curse = legend | Verified | Reburial late 1942 |
| Ulugh Beg observatory; Bibi-Khanym mosque; Nicopolis 1396 | NOT verified | Standard |

## Extension pass (added: War with Tokhtamysh; Syria and the Historian)
| Claim | Verdict | Notes |
|---|---|---|
| Timur helped Tokhtamysh to the White Horde throne 1378; war 1386–1395 | Verified (search) | |
| Kondurcha, 18 June 1391 | Verified (search) | One fandom site says 14 April; ignored |
| Terek 1395; Sarai and Astrakhan destroyed | Verified (search) | |
| Aleppo Nov 1400; Faraj retreated Jan 1401; Ibn Khaldun in camp about a month, declined to serve | Verified (search) | Length of stay 35 days vs a month |
| Damascus plundered, Umayyad Mosque damaged, Timur left mid-March 1401 | Verified (search) | Death tolls vary; not stated |
| Earlier claim "Terek ... helped Moscow" removed | Removed | Unsupported inference |
