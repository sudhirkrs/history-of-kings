# Ep 37 — Maria Theresa: The Empress Who Held an Empire Together

## 1. HOOK (0:00–0:42)
On 20 October 1740, Emperor Charles VI died at the age of fifty-six. His heir was his twenty-three-year-old daughter, Maria Theresa, who had no training in government. Within two months, the young king of Prussia, Frederick II, invaded her richest province, Silesia, without a declaration of war. Other powers, which had promised to respect her inheritance, began to line up to carve up her lands.
*Visual: a young woman in mourning, armies converging on a map of the Habsburg lands*
She was expected to lose. Instead she ruled for forty years, lost Silesia but kept everything else, rebuilt her army and her finances, reformed her schools, and bore sixteen children. This is the story of Maria Theresa.
*Visual: Maria Theresa portrait, Schönbrunn*

## 2. THE INHERITANCE (0:42–1:50)
The Habsburgs ruled a vast, mixed collection of lands: Austria, Bohemia, Hungary, parts of Italy and the Netherlands, and more. Each had its own laws and nobles. Only the dynasty held them together.
*Visual: patchwork map of Habsburg lands*
Charles VI had no sons. In 1713, he issued a decree called the Pragmatic Sanction, which declared the Habsburg lands indivisible and allowed a daughter to inherit if there was no son. The Hungarian Diet accepted it in 1723. He then spent the rest of his reign persuading the European powers to agree, often giving up territory and favours in return. Many of them later broke their word.
Maria Theresa was born on 13 May 1717 in Vienna. She was the oldest surviving child. After her elder brother's death she became the heir. In 1736, she married Francis Stephen of Lorraine, whom she loved, unusually for a royal match. Yet her father kept her out of government. When he died, she knew little about the treasury, the army or foreign affairs.

## 3. THE WAR OF THE AUSTRIAN SUCCESSION (1:50–3:10)
On 16 December 1740, Frederick II of Prussia marched into Silesia. Maria Theresa sent an army, but it was beaten at Mollwitz in April 1741. France, Bavaria, Spain and Saxony joined the attack. At one point, the Bavarian Elector, backed by France, was elected Holy Roman Emperor, and it looked as though the Habsburg state would be dismantled.
*Visual: Frederick's invasion, Mollwitz, coalition against Austria*
Maria Theresa turned to Hungary. In 1741, she appeared before the Hungarian nobles in Pressburg, carrying her infant son Joseph, and appealed for help. According to tradition, the nobles drew their swords and swore to give their lives and blood for her. Historians say the scene has been embroidered, and that she also had to make concessions to the Hungarian nobility, but Hungarian troops did help turn the tide.
*Visual: the Hungarian Diet, with a label: later tradition*
The war went on until 1748. In the end, she lost Silesia, the richest province, to Prussia, and some lands in Italy, but kept the rest of the monarchy. Her husband Francis Stephen was elected Holy Roman Emperor in 1745. She was Empress by marriage, and ruler in her own right.
Treaty of Aix-la-Chapelle in 1748 ended the war. Maria Theresa never accepted the loss of Silesia.

## 4. REBUILDING THE STATE (3:10–4:46)
Maria Theresa learned a lesson from the war: her state was too weak. She spent the following years reforming it.
*Visual: Vienna, ministers at a table*
She reformed the army and its finances. She created a central administration in Vienna, taking power from the provincial nobles. She raised taxes on the nobility and clergy, who had been largely exempt. She brought in capable advisers, among them Count Haugwitz for the internal reforms, and later Prince Kaunitz, who ran foreign policy for decades.
Kaunitz overturned Austria's old alliances. In 1756, in what historians call the Diplomatic Revolution, Austria allied with its old enemy, France, against Prussia. The result was the Seven Years' War of 1756 to 1763. Maria Theresa hoped to win back Silesia. She did not. At the Treaty of Hubertusburg in 1763, Silesia stayed with Prussia.
*Visual: Kaunitz, Austro-French alliance, Seven Years' War*
She also reformed education. Her General School Ordinance of 1774, drafted by the Silesian Catholic priest Johann Ignaz von Felbiger, required boys and girls from six to twelve to attend school or receive private instruction. It was unpopular with poor families, who needed their children to work, and enforcing it took pressure. But it was a step toward public education in Central Europe.
*Visual: schoolroom, Felbiger*
In the countryside, she tried to limit the labour that landlords could demand from serfs. A series of decrees in the 1770s, called the Robot patents, limited forced labour in some provinces, though the Hungarian nobility resisted strongly.

## 5. THE ARMY, KOLIN AND THE ORDER (4:46–5:57)
The reform of the army deserves a closer look. After the peace of 1748, Count Haugwitz began a systematic overhaul. New offices were set up to collect taxes directly from the provinces, which gave the Crown a steadier income, and the army was placed on a more regular footing, with a closer approach to conscription. In 1751 she founded a military academy at Wiener Neustadt, to train officers, and it is still known today as the Theresian Military Academy. Field Marshal Leopold von Daun had a large part in it.
*Visual: Haugwitz, Wiener Neustadt academy, drilling soldiers*
The new army had its test in the Seven Years' War. On 18 June 1757, at Kolin in Bohemia, Daun beat Frederick the Great in battle for the first time, and forced him to give up the siege of Prague. It was a famous victory, and Maria Theresa founded a new honour to commemorate it, the Military Order of Maria Theresa, awarded for gallantry to officers. But victories did not bring back Silesia, and the war ended where it began.
*Visual: Kolin, Daun, the Order's cross*

## 6. A MOTHER OF SIXTEEN (5:57–6:38)
Maria Theresa and Francis Stephen had sixteen children. She used them as tools of policy, arranging marriages across Europe to build alliances. The best known was her youngest daughter, Marie Antoinette, who married the future Louis XVI of France. The proxy wedding took place in Vienna on 19 April 1770, when the bride was fourteen.
*Visual: the family, Marie Antoinette's proxy marriage*
Her eldest son, Joseph, became co-regent after the death of his father in 1765, though she kept the final say on most matters. Mother and son clashed often. Joseph was impatient and wanted rapid reform, while Maria Theresa preferred compromise and caution, and was more religious.
*Visual: Joseph II and Maria Theresa, a study in contrast*

## 7. WIDOWHOOD AND SMALLPOX (6:38–7:45)
In August 1765 her husband, Francis Stephen, died suddenly, while on the way to the opera in Innsbruck. They had loved each other, which was unusual for a royal marriage of that time, and she was crushed. She wore black for the rest of her life, and gave up many pleasures. Yet she did not give up power. Her son Joseph became Emperor and co-ruler, but she kept control of the Habsburg lands, and the two continued to argue about the pace of change.
*Visual: Francis Stephen, Maria Theresa in widow's black*
Illness struck the family again in 1767. Maria Theresa herself caught smallpox, a deadly disease at the time, and survived, though her health seems never to have fully recovered. Her daughter, the Archduchess Maria Josepha, died of the disease in October that year, and Joseph's wife had died of it earlier, in May. It was a reminder of how fragile even a royal family was, and it is said to have changed her view of inoculation.
*Visual: smallpox ward, the family tree*

## 8. THE DARKER SIDE (7:45–8:31)
Maria Theresa was a devout Catholic, and her record on religion was harsh. In December 1744, she ordered the Jews to leave Prague, and in 1745 the rest of Bohemia. About ten thousand people in Prague were affected. The order was rolled back in stages under pressure from foreign powers and her own local officials, and was cancelled in 1748, but with a heavy annual tax for the right to stay. Historians see this as an episode driven by prejudice as well as politics.
*Visual: expulsion from Prague, tax*
She also persecuted Protestants in some regions, sending them to remote parts. It was her son Joseph who issued the Edict of Toleration in 1781, after her death.
*Visual: Joseph's Edict of Toleration, contrast*

## 9. THE FIRST PARTITION OF POLAND (8:31–8:59)
In 1772, Russia, Prussia and Austria agreed to the first partition of Poland. Maria Theresa had qualms. She wrote that she did not like to take what did not belong to her. But Austria took a large region, Galicia, as her share. A quotation often attributed to Frederick the Great says: she wept, but she took. The saying is a witty summary, though its source is uncertain.
*Visual: the first partition map*

## 10. THE BAVARIAN SUCCESSION (8:59–9:34)
In 1777 the Bavarian ruling line died out, and Joseph moved to claim part of Bavaria for Austria. Frederick the Great opposed him, and war threatened. Maria Theresa, now old and tired, disliked the idea of fighting once more, and is known to have made peace overtures to Frederick behind Joseph's back. The fighting was little more than manoeuvres. The conflict was ended by the Treaty of Teschen on 13 May 1779. It was one of her last acts as a ruler: to end a war.
*Visual: Joseph and Frederick, Teschen, a peace letter*

## 11. DEATH AND LEGACY (9:34–10:24)
Maria Theresa died on 29 November 1780, aged 63, in Vienna. She had ruled for forty years, a woman in a world of men, and she had saved her inheritance. She left a more centralised, more efficient state, with a stronger army and schools.
*Visual: her tomb in the Capuchin Crypt, Vienna*
Historians still discuss several questions. Was she an enlightened ruler or a cautious conservative? How much credit belongs to her advisers? How should one weigh her reforms against her intolerance? And what would have happened if she had held on to Silesia?
*Visual: question cards*
Next, we go back to the eleventh century, and a prince of Kiev who brought law and learning to the Rus': Yaroslav the Wise. Subscribe, and tell me which king you want after that.
*Visual: end screen*

## Fact-check flags
- [ ] Born 13 May 1717; Charles VI d. 20 Oct 1740 (verified).
- [ ] Pragmatic Sanction 19 April 1713; Hungarian Diet accepted 1723 (verified).
- [ ] Frederick invaded Silesia 16 Dec 1740; Mollwitz 10 April 1741; war 1740–48 (verified).
- [ ] Hungarian Diet 1741, "vitam et sanguinem": NOT verified by search; flagged as tradition.
- [ ] Francis Stephen elected emperor 1745; Aix-la-Chapelle 1748: NOT verified.
- [ ] Haugwitz, Kaunitz, Diplomatic Revolution 1756, Hubertusburg 1763: NOT verified in search.
- [ ] School Ordinance 1774, Felbiger; ages 6–12; enforced with threats (verified).
- [ ] Robot patents 1771–78 (verified; Hungary resisted).
- [ ] Marie Antoinette proxy marriage 19 April 1770 (verified).
- [ ] Joseph co-regent 1765 after Francis's death (verified, "declared co-regent").
- [ ] Jews expelled from Prague Dec 1744/1745; revoked 1748 with toleration tax (verified).
- [ ] Protestants sent to remote regions: NOT verified.
- [ ] First Partition 1772, Galicia; "she wept, but she took": NOT verified.
- [ ] Death 29 Nov 1780, Capuchin Crypt; sixteen children: NOT verified in search.

## Metadata
Title: Maria Theresa: The Empress Who Held the Habsburg Empire Together
Hook: At 23 she inherited an empire that Europe wanted to carve up. Maria Theresa lost Silesia but kept her realm, reformed it, and bore sixteen children. Achievements and shadows.
Tags: Maria Theresa, Habsburg, Austria, Empress, War of the Austrian Succession, Frederick the Great, Marie Antoinette, history of kings
Hashtags: #MariaTheresa #Habsburg #HistoryOfKings
Sources:
- Barbara Stollberg-Rilinger, Maria Theresa: The Habsburg Empress in Her Time
- Edward Crankshaw, Maria Theresa
- Derek Beales, Joseph II (vol. 1)
- Karl Vocelka, Habsburgs
- P.G.M. Dickson, Finance and Government under Maria Theresia

## Fact-check log
(Search-first drafting: facts were searched before writing; items below show what search confirmed. See factcheck/README.md for limits.)

| Claim | Verdict | Notes |
|---|---|---|
| Born 13 May 1717; Charles VI d. 20 Oct 1740; Pragmatic Sanction 19 April 1713 (Hungary accepted 1723) | Verified | Several powers later reneged |
| Frederick invaded Silesia 16 Dec 1740; Mollwitz 10 April 1741; war 1740–48 | Verified | |
| Hungarian Diet 1741, swords drawn | NOT verified; labelled tradition | |
| Francis Stephen emperor 1745; Aix-la-Chapelle 1748; Haugwitz, Kaunitz, Diplomatic Revolution 1756; Hubertusburg 1763 | NOT verified | Standard |
| School Ordinance 1774 (Felbiger), ages 6–12, enforced | Verified | |
| Robot patents 1771–78 | Verified | Hungarian nobility resisted |
| Marie Antoinette proxy wedding 19 April 1770 | Verified | |
| Joseph co-regent 1765 | Verified | |
| Jews expelled from Prague Dec 1744; revoked 1748 with toleration tax | Verified | |
| Protestants sent to remote regions | NOT verified | |
| First Partition 1772; "she wept, but she took" | NOT verified; attribution uncertain | |
| Died 29 Nov 1780; sixteen children | NOT verified in search | Standard |

## Extension pass (added sections: Army, Kolin and the Order; Widowhood and Smallpox; Bavarian Succession)
| Claim | Verdict | Notes |
|---|---|---|
| Haugwitz reforms after 1748; academy at Wiener Neustadt 1751 | Verified (search) | Earlier "108,000 army" figure NOT used |
| Kolin 18 June 1757, Daun's first win over Frederick; Military Order of Maria Theresa | Verified (search) | |
| Francis Stephen died Aug 1765 at Innsbruck, en route to the opera | NOT verified in this pass | Standard; check |
| She wore mourning for life; kept power over Joseph | Verified (search) | |
| 1767 smallpox; daughter Maria Josepha d. Oct 1767; Joseph's wife d. May 1767 | Verified (search) | Two different Maria Josephas; do not confuse |
| "Changed her view of inoculation" | Hedged ("is said to") | Check a biography |
| Treaty of Teschen 13 May 1779; secret peace overtures behind Joseph | Verified / hedged | Overtures widely reported |
| Death date 29 Nov 1780 | FLAG | One source gives 28 Nov; most give 29 Nov. Check |
