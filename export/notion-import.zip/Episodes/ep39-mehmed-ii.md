# Ep 39 — Mehmed the Conqueror: The Sultan Who Took Constantinople

## 1. HOOK (0:00–0:49)
In the spring of 1453, a twenty-one-year-old sultan surrounded the greatest city of Christian Europe with an army of tens of thousands, a fleet of hundreds of ships, and a bronze cannon so large that it took dozens of oxen to move. For almost two months, the walls of Constantinople, which had stood for a thousand years, held out.
*Visual: Theodosian walls, the great cannon, the Ottoman fleet*
On 29 May, the city fell. The Byzantine Empire, the last remnant of ancient Rome, ended. The sultan was Mehmed II, later known as Fatih, the Conqueror. He was also a scholar, who spoke several languages, invited a Venetian painter to his court, and rebuilt the city as an imperial capital. This is the story of Mehmed the Conqueror.
*Visual: Mehmed portrait, Constantinople*

## 2. A PRINCE AND TWO REIGNS (0:49–1:48)
Mehmed was born on 30 March 1432, the son of Sultan Murad II. As a boy he was sent to govern a province, and educated by tutors in religion, languages and military training. At twelve, in 1444, his father gave up the throne, and Mehmed became sultan for the first time. His reign was short. When a crusader army threatened, the viziers called Murad back, and Mehmed was sent away to govern again. In 1446 he was removed.
*Visual: Murad II, boy Mehmed on the throne*
The humiliation stayed with him. Murad died in 1451, and Mehmed, nineteen, came to the throne for the second time. One of his first acts was said to be the order for the death of his infant half-brother, to remove any rival. This was in line with an old Ottoman habit. Mehmed later made it a rule.
Almost immediately he started planning the conquest of Constantinople.

## 3. A CITY DIVIDED (1:48–2:34)
Before the siege, the city's own people were divided. The emperor, Constantine XI, hoped for help from the West, and the Pope would only help if the Greek Church accepted union with Rome. In December 1452, in Hagia Sophia, the union was proclaimed by Cardinal Isidore of Kiev, sent by Pope Nicholas V. But many Greeks hated the idea. The churchman Gennadios Scholarios opposed it, and after the fall of the city, he rejected it for good. A famous remark, attributed to a Byzantine official, says he would rather see the Turkish turban in the city than the cardinal's hat. It was probably recorded later, but it shows the mood.
*Visual: Hagia Sophia, Isidore of Kiev, a divided crowd*

## 4. THE CITY AND THE GUN (2:34–3:40)
By 1451 Constantinople was a shadow of its former self. The Byzantine Empire consisted of the city itself and a few lands in Greece, surrounded by the Ottomans. The city had perhaps fifty thousand people, down from several hundred thousand at its peak. Yet it had massive land walls, built in the fifth century under Theodosius, with a double wall, a moat, and about a hundred towers.
*Visual: Constantinople in 1450, land walls cross-section*
Mehmed prepared carefully. He built a fortress on the European side of the Bosphorus, Rumeli Hisari, to control the strait. He gathered an army of perhaps fifty to eighty thousand men, according to different estimates, and a fleet.
He also recruited a Hungarian engineer called Orban, who offered his services to the Byzantine emperor, Constantine XI. The emperor lacked the money to pay him, and Orban turned to Mehmed. In 1452, Orban cast a huge cannon at Edirne, said to be around eight metres long. The Ottomans also had over seventy other guns.
*Visual: Rumeli Hisari, Orban, the great bombard*

## 5. THE STRAIT AND THE FORTRESS (3:40–4:19)
The fortress deserves a closer look. In the spring of 1452 he began building a fortress at the narrowest point of the Bosphorus, on the European shore, opposite one that his great-grandfather Bayezid I had built on the Asian side. The work was done in about four months, with thousands of workers, and the new fortress, Rumeli Hisari, put the strait in Ottoman hands. Ships could now be stopped and searched. With both shores controlled, help sent from the Black Sea could be cut off. The Byzantines understood very well what this meant.
*Visual: Rumeli Hisari, the Bosphorus, a chain of fortresses*

## 6. THE SIEGE (4:19–5:41)
The siege began in early April 1453. The Ottoman guns pounded the walls, but at first the walls held. The huge cannon was slow to load, firing perhaps seven times a day, and the defenders repaired breaches each night with timber, stones and barrels.
*Visual: bombardment, defenders repairing breaches*
At sea, the Ottomans could not break the chain across the Golden Horn. According to the traditional account, Mehmed had ships dragged overland on greased logs, around the Genoese colony of Galata, and launched into the Golden Horn. This forced the defenders to stretch their thin forces along the sea walls.
The defenders were a few thousand, with Greeks, Venetians, Genoese, and others, led by the Emperor Constantine XI and the Genoese captain Giovanni Giustiniani. Help from the West did not arrive.
On the night of 28 to 29 May, Mehmed ordered a general assault. After hours of fighting, Giustiniani was wounded and withdrew, and the defence collapsed. The Ottomans poured into the city on 29 May. Constantine XI is believed to have died in the fighting. His body was never certainly identified.
*Visual: ships on land, final assault, Constantine's last stand*
The city was plundered for three days, according to custom. Many were killed, and thousands enslaved. Then Mehmed ordered the looting to stop.

## 7. REBUILDING THE CITY (5:41–6:51)
Mehmed made Constantinople, later called Istanbul, his capital. He needed it repopulated. He ordered people from across the empire, Turks, Greeks, Armenians, Jews and others, to move there. He rebuilt walls and markets, built a new palace, and from 1459, began the Topkapi Palace.
*Visual: Istanbul rebuilding, Topkapi*
The great church of Hagia Sophia was converted into a mosque. Mehmed also supported the Orthodox Church, allowing a patriarch, Gennadios, to be appointed, as the head of the Orthodox community. This became the basis for what was later called the millet system, in which religious communities had their own laws. The details of this system developed later. Historians debate how much of it was Mehmed's design.
*Visual: Hagia Sophia, patriarch, communities*
Mehmed was a man of wide interests. He spoke Turkish, Persian, Arabic, Greek, and apparently some Latin and Serbian. He collected books and maps, and invited artists and scholars from Italy. In 1479 to 1481 the Venetian painter Gentile Bellini lived in Istanbul, as part of the peace treaty between Venice and the Ottomans, and painted Mehmed's portrait.
*Visual: Bellini portrait, library*

## 8. A CONQUEROR TO THE END (6:51–7:48)
After 1453, Mehmed continued to expand. He took Serbia, in stages in the 1450s. In 1456, he lost: his army besieged Belgrade, and was repulsed by the forces of the Hungarian commander John Hunyadi. In 1461 he took Trebizond, the last Greek state on the Black Sea. In 1463 he conquered Bosnia, and in the long Ottoman-Venetian war of 1463 to 1479, took parts of Albania and the Aegean. He also expanded in Anatolia, and in the Crimea.
*Visual: animated map of conquests*
In 1480, one of his commanders, Gedik Ahmed Pasha, landed in southern Italy and took the city of Otranto. It looked as if Mehmed might invade Italy. But he died in the spring of 1481, on 3 May, while on campaign, and Otranto was given up.
*Visual: Otranto, Mehmed's death*
His succession was disputed between his sons, Bayezid and Cem. Bayezid won.

## 9. MEHMED THE RULER (7:48–8:52)
Beyond wars, Mehmed built a system of government. He is known for his law codes, the kanunname, which set out rules on taxes, offices and crimes, and in many ways laid down the structure of the empire. He relied on officials who owed their rise to him rather than to the old noble families, and many of them came from the devshirme, the system that took Christian boys into service at a young age. In his reign, power moved from the old Turkish lords to the sultan's own household.
*Visual: law code, the sultan's court, Janissaries*
A darker rule is also attached to his name. A law in his code is read to allow a sultan's successor to execute his brothers, to prevent civil war. Historians discuss how strictly it was meant, but fratricide became a feature of Ottoman succession. After Mehmed's death, his sons Bayezid and Cem fought for the throne, which showed exactly the danger the rule was meant to prevent.
*Visual: the kanunname, two rival princes*

## 10. LEGACY AND DEBATE (8:52–9:55)
Mehmed's conquest of Constantinople is seen as a turning point in history. It marked the end of the Byzantine Empire and the beginning of the Ottoman Empire as a world power. Some historians use it as the end of the Middle Ages, though this is a convenient label.
*Visual: 1453 dividing line*
He is a hero in Turkey, a conqueror whose name is borne by streets and bridges. In Greece and elsewhere in the Balkans, the memory is different.
Historians debate several points. How decisive was the great cannon? Was the siege plan as brilliant as the story says, or did the weak defence count more? How tolerant was he really? And was he the ruler who made the empire, or was he building on his father's work?
*Visual: question cards*
Next, we go to China, where a poor peasant orphan rose to found the Ming dynasty: Zhu Yuanzhang. Subscribe, and tell me which king you want after that.
*Visual: end screen*

## Fact-check flags
- [ ] Born 30 March 1432; two reigns 1444–46 and 1451–81 (verified); birthplace Edirne (weak source).
- [ ] Killed infant half-brother 1451: NOT verified by search; fratricide law: NOT verified.
- [ ] Orban offered to Constantine first; cast gun at Edirne 1452, ~8 m (verified from French source; Wikipedia).
- [ ] Army size 50–80,000; Constantinople population ~50,000: NOT verified.
- [ ] Siege began early April (6 April in one source); walls initially held (verified).
- [ ] Ships dragged overland to the Golden Horn; Giustiniani wounded; assault 28–29 May; Constantine's death: NOT verified by search.
- [ ] Fall 29 May 1453 (date NOT confirmed in search; universally cited).
- [ ] Topkapi from 1459 (verified, "New Palace"); Hagia Sophia converted (single weak source).
- [ ] Gennadios and millet system: NOT verified; development later.
- [ ] Languages: Persian, Arabic, Greek, Latin, Serbian (one source).
- [ ] Bellini 1479–81 as part of the peace with Venice (verified); portrait dated 25 Nov 1480.
- [ ] Belgrade 1456 repulsed (verified); Serbia 1459 or 1454–55 (sources differ); Trebizond 1461; Bosnia 1463; Albania 1478.
- [ ] Otranto 1480 (Gedik Ahmed Pasha); Mehmed d. 3 May 1481 (verified); Gebze not confirmed.
- [ ] Bayezid vs Cem: NOT verified.

## Metadata
Title: Mehmed the Conqueror: The Sultan Who Took Constantinople at 21
Hook: The great cannon, the ships over the hill, the last stand of Constantine XI and the making of Istanbul. The story of Mehmed II and the fall of Constantinople in 1453.
Tags: Mehmed II, Mehmed the Conqueror, Fall of Constantinople, 1453, Ottoman Empire, Byzantine Empire, Hagia Sophia, history of kings
Hashtags: #MehmedII #Constantinople #HistoryOfKings
Sources:
- Halil Inalcik, The Ottoman Empire: The Classical Age
- Franz Babinger, Mehmed the Conqueror and His Time
- Roger Crowley, 1453: The Holy War for Constantinople
- Caroline Finkel, Osman's Dream
- Steven Runciman, The Fall of Constantinople 1453

## Fact-check log
(Search-first drafting: facts were searched before writing; items below show what search confirmed. See factcheck/README.md for limits.)

| Claim | Verdict | Notes |
|---|---|---|
| Born 30 Mar 1432; two reigns 1444–46 and 1451–81 | Verified | Birthplace Edirne: weak source |
| Killed infant half-brother 1451; fratricide law | NOT verified | |
| Orban: offered to Constantine first; cannon cast 1452 at Edirne ~8 m; 70+ guns | Verified | |
| Army size, city population; ships dragged overland; Giustiniani; assault 28–29 May; Constantine's death | NOT verified in search | Standard account |
| Fall of Constantinople 1453 (29 May) | Year verified; day not stated in search | |
| Topkapi from 1459 | Verified | |
| Hagia Sophia mosque; Gennadios/millet | Weak/NOT verified | Millet developed later |
| Languages incl. Persian, Arabic, Greek, Latin, Serbian | Verified (one source) | |
| Bellini in Istanbul 1479–81; portrait dated 25 Nov 1480 | Verified | |
| Belgrade 1456 failed; Serbia 1459 (or 1454–55); Trebizond 1461; Bosnia 1463; Albania 1478 | Verified (dates vary) | |
| Otranto 1480 (Gedik Ahmed Pasha); died 3 May 1481 | Verified | Place of death not confirmed |

## Extension pass (added sections: A City Divided; The Strait and the Fortress; Mehmed the Ruler)
| Claim | Verdict | Notes |
|---|---|---|
| Union proclaimed in Hagia Sophia Dec 1452 by Isidore of Kiev, sent by Nicholas V | Verified (search) | |
| Gennadios opposed, repudiated union after the fall | Verified (search) | |
| "Turban rather than cardinal's hat" remark | Hedged | Attributed (usually to Notaras); probably recorded later |
| Rumeli Hisari spring 1452, ~4 months, opposite Bayezid I's fortress | Verified (search) | |
| Kanunname, devshirme officials, power shifting to sultan's household | NOT verified in this pass | Standard; check |
| Fratricide law; Bayezid vs Cem | Hedged | Check wording of the law in a book |
