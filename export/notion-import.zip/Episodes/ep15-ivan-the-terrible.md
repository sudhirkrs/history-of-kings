# Ep 15 — Ivan the Terrible: Russia's First Tsar

## 1. HOOK (0:00–0:50)
In January 1547, a sixteen-year-old boy stood in the Dormition Cathedral in Moscow, and was crowned not as Grand Prince, but as Tsar of all Russia, the first ruler in Russian history to take that title. In the following thirty-seven years, he would conquer two khanates, double the size of his realm, create the first standing infantry in Russia, and also destroy a city in his own country, kill thousands of his subjects and, according to tradition, murder his own son.
*Visual: coronation in the cathedral, then dark symbols of terror*
He is known as Ivan the Terrible. But the Russian word Grozny does not quite mean terrible. It means formidable, or awe-inspiring. In this video, we follow Ivan from a frightened child to a feared ruler, and ask what really made him.
*Visual: Ivan portrait*

## 2. A LONELY CHILDHOOD (0:50–3:00)
Ivan was born on 25 August 1530, the son of Grand Prince Vasily III and his second wife, Elena Glinskaya. His father died when he was three, in 1533. His mother ruled as regent, until she died suddenly in 1538, when Ivan was eight. Many people believe she was poisoned. Some studies of her remains have reported high levels of mercury, though what they prove is debated.
*Visual: young Ivan, Elena Glinskaya's funeral*
After that, the boyar families, the great nobles, fought for control. Ivan's own memories, written years later in letters, describe being treated like a beggar, ignored and humiliated, while the boyars looted the treasury. He spent his childhood in a court of intrigue. At thirteen, in 1543, he had Andrei Shuisky, a leader of the Shuisky family, arrested, and, according to the chronicles, handed to the keepers of the hunting dogs, who killed him. Ivan took power into his own hands in 1544. It showed his character early.
*Visual: boyars quarrelling, hunting dogs*
Historians see a deep effect on his mind: mistrust, fear and a conviction that nobles were his enemies.

## 3. THE FIRST TSAR AND THE GOOD YEARS (3:00–6:00)
On 16 January 1547, Ivan was crowned Tsar, a title taken from Caesar and used earlier for Byzantine emperors and Mongol khans. It made him equal to the emperors of the world. A few weeks later he married Anastasia Romanovna, from a boyar family. By all accounts it was a happy marriage.
*Visual: coronation, Ivan and Anastasia*
In June 1547, a huge fire destroyed much of Moscow, and a riot broke out against the Glinsky relatives of the Tsar. Ivan was badly shaken. He turned to advisors: the priest Sylvester and the courtier Aleksei Adashev. They formed a group called the Chosen Council.
Between 1547 and 1560, Russia saw big reforms. A new law code, the Sudebnik of 1550, set out courts and punished corruption. In 1549 the first Zemsky Sobor, an assembly of the land, was held. The army was reorganised. A new infantry force with firearms, the streltsy, was created around 1550. The church was reformed at the Stoglav Council of 1551.
*Visual: Sudebnik, assembly of the land, streltsy with muskets*
These years are called the good years of Ivan's reign.

## 4. KAZAN, ASTRAKHAN AND ST BASIL'S (6:00–8:30)
The first big goal was Kazan, the Tatar khanate on the middle Volga, a long-time enemy that raided Russian lands and took slaves. After failed attempts in 1547 and 1549, Ivan led a huge army, traditionally put at about 150,000 men, in 1552. Engineers dug mines under the walls and filled them with gunpowder. On 2 October 1552, the explosions brought down the walls, and the Russians stormed in. Kazan fell.
*Visual: siege of Kazan, mines exploding*
In 1556, Astrakhan, the khanate at the mouth of the Volga, was taken without a major fight. The entire Volga now belonged to Russia. This opened the way to the Caspian Sea, and to Siberia.
To mark the victory, Ivan ordered a cathedral on Red Square: the Cathedral of the Intercession, later known as St Basil's. It was built from 1555 to 1561, with nine chapels around a central tower, each with a different dome. A later legend says Ivan blinded the architects so they could never build anything as beautiful. Historians treat this as a myth. The architects are not certain: names like Postnik Yakovlev and Ivan Barma are given, and some scholars think they may be the same man, while others suggest a European master.
*Visual: St Basil's, domes, architects*

## 5. THE TURN (8:30–11:00)
In 1553 Ivan fell ill, and nearly died. He asked the boyars to swear loyalty to his infant son, Dmitry. Many hesitated, and some favoured his cousin Vladimir of Staritsa. Ivan never forgave them.
*Visual: sickbed, boyars refusing to swear*
In 1558, Ivan launched a war for the Baltic coast, the Livonian War. Russia wanted a port to trade with Western Europe. At first they won. But then Poland-Lithuania, Sweden and Denmark joined in against Russia. It dragged on for twenty-five years and ended in failure.
In 1560, Anastasia died, probably of an illness, although Ivan thought she had been poisoned. He broke with his advisors, Sylvester and Adashev, who were banished. In 1564, one of his closest commanders, Prince Andrei Kurbsky, defected to Lithuania. He and Ivan exchanged long, angry letters, in which Kurbsky accused him of tyranny, and Ivan defended the divine right of a Tsar.
*Visual: Anastasia's death, Kurbsky and Ivan's letters*

## 6. THE OPRICHNINA (11:00–14:30)
In December 1564, Ivan left Moscow suddenly with his family and treasury, and settled in a village, Aleksandrova Sloboda. In January 1565 he sent a letter saying he was giving up the throne because of the treachery of the boyars and clergy. The people begged him to return. He agreed, on one condition: he would have absolute freedom to punish traitors.
*Visual: Ivan's departure, letters, crowds begging*
Then he divided the country in two. One part, the zemshchina, was left to the old administration. The other, the oprichnina, was the Tsar's personal domain, with its own lands, army and officials. The members of the oprichnina, the oprichniki, wore black, rode black horses and carried a dog's head and a broom as symbols, meaning that they would bite and sweep away treason, according to the foreign accounts of Heinrich Staden and Albert Schlichting.
*Visual: oprichniki in black, dog's head and broom*
They seized lands, executed boyars and terrorised the population. In 1568 the metropolitan Philip was removed, and later killed, after criticising Ivan. In 1570, Ivan marched on Novgorod, suspecting it of treason. For about five weeks, the oprichniki tortured and killed the townspeople. The number of dead is debated: estimates run from about 2,000 to 15,000 or more. In 1571, the Crimean Tatars under Devlet Giray burned Moscow, while the oprichnina army failed to defend it. Ivan abolished the oprichnina in 1572.
*Visual: Novgorod massacre, Moscow burning in 1571*
Historians have long argued about it. Some, like the Soviet-era scholars, saw it as a rational policy to break the power of the boyars. Others, like Ruslan Skrynnikov, saw it as pure terror driven by paranoia. Most today say it was inefficient, and damaging.

## 7. THE SON AND THE LAST YEARS (14:30–17:00)
Ivan married six more times after Anastasia, although the Church allowed only three marriages. In November 1581, in a fit of rage, he struck his pregnant daughter-in-law, and when his son Ivan Ivanovich protested, he hit him on the head with his staff. The prince died days later. This is the scene famously painted by Ilya Repin in 1885.
*Visual: Repin's painting, with a note: 19th-century painting*
Some historians question the story. The only contemporary source is a Jesuit, Antonio Possevino, writing for readers abroad, and the historian Paul Bushkovitch has argued that there is no reliable evidence that Ivan killed his son. Others accept that the death took place in a violent quarrel. In 1963, when the tombs were opened, scientists found high levels of mercury and other metals in the bones of both father and son. That could be from medicines of the time or from poison. The result settled nothing.
Whatever the case, Ivan was left with his younger son, Feodor, who was weak and slow, and baby Dmitry.
In the 1580s, a Cossack named Yermak, backed by the Stroganov merchants, crossed the Urals and defeated the Siberian khan Kuchum. This was the start of the conquest of Siberia.
*Visual: Yermak crossing the Urals*
Ivan died on 18 March 1584, apparently while preparing to play chess. He was fifty-three.

## 8. LEGACY AND DEBATE (17:00–19:00)
Ivan left a vast country, with the Volga basin and the road to Siberia, a standing infantry, and a new idea of the Tsar's absolute power. He also left a ruined economy, a depopulated north, and a dynasty about to end. After his son Feodor died in 1598, Russia fell into the Time of Troubles.
*Visual: map of Russia 1584, empty throne*
Historians still debate whether he was mad or a rational ruler; whether the oprichnina had a purpose; whether his legend was created by foreign writers; and whether Stalin, who admired Ivan, shaped the modern image.
*Visual: question cards, Stalin and the film Ivan the Terrible*
Next, we jump ahead 120 years to the tsar who built a new capital on a swamp and forced Russia into Europe: Peter the Great. Subscribe, and tell me which king you want after that.
*Visual: end screen*

## Fact-check flags
- [ ] Born 25 Aug 1530; Elena d. 1538 (mercury studies debated); Shuisky 1543; personal rule 1544.
- [ ] Coronation 16 Jan 1547; marriage to Anastasia Feb 1547; Moscow fire June 1547.
- [ ] Kazan fell 2 Oct 1552; Astrakhan 1556; army size.
- [ ] St Basil's 1555–61; blinding legend: myth.
- [ ] 1553 illness; Anastasia d. 1560; Kurbsky 1564.
- [ ] Oprichnina 1565–72: Staden/Schlichting symbols (dog head and broom).
- [ ] Novgorod 1570: death toll estimates; Philip's death 1569.
- [ ] Devlet Giray burnt Moscow 1571.
- [ ] Death of the tsarevich Nov 1581; Possevino as source; Repin 1885.
- [ ] Mercury in remains (1963 exhumation).
- [ ] Yermak 1581–82; death of Ivan 18 Mar 1584.

## Metadata
Title: Ivan the Terrible: The First Tsar of Russia
Hook: The boy tsar, the conquest of Kazan, St Basil's, the oprichnina and the death of his son. Separating Ivan the Terrible's legend from the evidence.
Tags: Ivan the Terrible, Ivan IV, Tsar, Russia, Oprichnina, Kazan, St Basil's Cathedral, Russian history, history of kings
Hashtags: #IvanTheTerrible #Russia #HistoryOfKings
Sources:
- Isabel de Madariaga, Ivan the Terrible: First Tsar of Russia
- Ruslan Skrynnikov, Ivan the Terrible
- Janet Martin, Medieval Russia 980-1584
- Charles Halperin, Ivan the Terrible: Free to Reward and Free to Punish
- Heinrich Staden, The Land and Government of Muscovy

## Fact-check log
| Claim | Verdict | Notes |
|---|---|---|
| Born 25 Aug 1530 Kolomenskoye; coronation 16 Jan 1547 (O.S.) | Verified | Wikipedia infobox 26 Jan (calendar) |
| Elena Glinskaya d. 1538 (3/4 April), poisoned | Verified as "many believe" | Mercury study not confirmed in search — FIXED |
| Shuisky thrown to dogs 1543 | Not verified; regency ended 1544 per sources — FIXED | |
| Kazan siege 23 Aug–2 Oct 1552; mines; ~150,000 (traditional) | Verified — FIXED | Defenders 40–60,000 |
| Astrakhan 1556 | Not verified in search | Standard |
| St Basil's 1555–61; architects uncertain (Barma/Postnik); blinding legend | Verified as myth — FIXED | |
| Oprichnina 1565–72; dog's head and broom | Verified (Russian source) | Staden not confirmed |
| Novgorod 1570 deaths 2,000–15,000 | Verified — FIXED (was 3,000–15,000) | |
| Metropolitan Philip strangled Dec 1569 by Skuratov | Single source | |
| Killing of son Nov 1581 | Verified as UNCERTAIN — FIXED | Possevino sole source; Bushkovitch (2014) sees no reliable evidence; Repin painted 1883–85 |
| 1963 exhumation: mercury | Verified, inconclusive — FIXED | |
| Death 18 March 1584 (O.S.), chess | Verified | Suspected foul play by some contemporaries |
| Sudebnik 1550, Zemsky Sobor 1549, Stoglav 1551, streltsy 1549/1550 | Verified; streltsy date varies — FIXED | |
| Chosen Council name given later by Kurbsky | Verified | |
| Kurbsky 1564; Anastasia d. 1560; Devlet Giray 1571; Livonian War 1558–83; Yermak 1581–82 | Not verified in search | Standard dates |
